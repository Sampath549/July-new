﻿$(document).ready(function () {
    GetTable();

    $('#tblGetErrorLog').on("click", ".editErrorLog", function (event) {
        event.preventDefault();
        var url = $(this).attr("href");
        var _name = getURLParameter(url, 'name'); // calling another function

        //window.open("/CPanelDev/ViewErrorLog_TextFile?IdVal=" + _name);

        window.location.href = "/CPanelDev/ViewErrorLog_TextFile?IdVal=" + _name;

        //swal({
        //    title: "Warning!",
        //    text: "Will be Opened in New Tab",
        //    type: "warning",
        //    confirmButtonText: "OK"
        //},
        //function (isConfirm) {
        //    if (isConfirm) {
        //        window.open("/CPanelDev/ViewErrorLog_TextFile?IdVal=" + _name);
        //    }
        //});
    });

    $('#tblGetErrorLog').on("click", ".deleteErrorLog", function (event) {
        event.preventDefault();
        var url = $(this).attr("href");
        var _name = getURLParameter(url, 'name'); // calling another function

        swal({
            title: "Are you sure?",
            text: "This will delete the Record",
            type: "warning",
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, Delete it!",
            closeOnConfirm: false
        },
        function (isConfirm) {
            $(".loadingImg").show();
            if (isConfirm) {
                $.ajax({
                    url: '/CPanelDev/DeleteErrorLog',
                    type: 'POST',
                    data: JSON.stringify({ "IdVal": _name }),
                    contentType: 'application/json; charset=utf-8;',
                    success: function (result) {
                        if (result.Status) {
                            swal("Deleted!", result.Message, "success");
                            GetTable();
                        }
                        else
                            swal("Cancelled!", result.Message, "error");
                    }
                });
            }
            $(".loadingImg").hide();
        }
    );
    });
});

function getURLParameter(url, name) {
    return (RegExp(name + '=' + '(.+?)(&|$)').exec(url) || [, null])[1];
}

function GetTable() {
    Table = $('#tblGetErrorLog').DataTable({
        "processing": true,
        "serverSide": false,
        "paging": true,
        "ordering": true,
        "info": true,
        "searching": true,
        "bFilter": false,
        "scrollX": "100%",
        "scrollY": ($(window).height() - 500),
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "sAjaxSource": '/CPanelDev/GetErrorLogGrid',
        "bDestroy": true,
        "bLengthChange": true,
        "bPaginate": true,
        "sEmptyTable": "Loading data from server",

        "columns": [
            { "sWidth": "10%", "sClass": "TextCenter Header", "render": function (data, type, row) { return (row[0]); } },
            { "sWidth": "80%", "sClass": "TextCenter Header", "render": function (data, type, row) { return (row[1]); } },
            {
                "sWidth": "10%",
                "bSortable": false,
                "sClass": "TextCenter",
                "render": function (data, type, row) {
                    return '<center><a href="/CPanelDev/ViewErrorLog?name=' + row[1] + '"  class="editErrorLog" title="View" return false;> <i class="glyphicon glyphicon-eye-open"></i></a>&nbsp;&nbsp;<a href="/CPanelDev/DeleteErrorLog?name=' + row[1] + '" class="deleteErrorLog" title="Delete" return false;> <i class="glyphicon glyphicon-trash"></i></a>&nbsp;&nbsp;</center>';
                }, "targets": 0,
            }
        ],
    });
}