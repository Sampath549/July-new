﻿var opts = {
    "closeButton": true,
    "debug": false,
    "positionClass": "toast-top-full-width",
    "onclick": null,
    "showDuration": null,
    "hideDuration": null,
    "timeOut": null,
    "extendedTimeOut": null,
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
};

$(document).ready(function () {

    $("#BMembersDetails").validate({
        submitHandler: function () {
            $(".loadingImg").show();
            setTimeout(function () {
                var _List = [];
                $.each($("#UserId option:selected"), function () {
                    _List.push($(this).val());
                });

                if (_List.length == 0) {
                    toastr.error("Please Select atleast One User", null, opts);
                    $(".loadingImg").hide();
                    return false;
                }

                var _postData = { UserIds: _List };

                $.ajax({
                    type: "POST",
                    url: "/CPanelCommunity/InsertBMembers",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        if (!response.Status) {
                            toastr.error(response.Message, response.Caption, opts);
                            $("#CreateAddBMembersModel").modal('show');
                        }
                        else {
                            $("#CreateAddBMembersModel").modal('hide');
                            swal({
                                title: response.Caption,
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    window.location.href = "/CPanelCommunity/BoardMembers";
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        alert(xhr.responseText);
                    }
                });
            }, 0);
        }
    });
});