﻿
$(document).ready(function () {

    // AutoComplete
    $("#CommunityId").autocomplete({
        source: function (request, response) {
            $.ajax({
                url: '/User/AutoCompleteCommunities/',
                data: "{ 'prefix': '" + request.term + "'}",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    response($.map(data, function (item) {
                        return item;
                    }))
                },
                error: function (response) {
                    window.location.href = '/Error/InternalServerError';
                },
                failure: function (response) {
                    window.location.href = '/Error/InternalServerError';
                }
            });
        }
    });
});