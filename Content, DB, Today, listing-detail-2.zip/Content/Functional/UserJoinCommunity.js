﻿$(document).ready(function () {

    $("#btnAddRecord").click(function () {
        var url = $(this).data("url");
        $.get(url, function (data) {
            $('#CreateJoinCommunityData').html(data);
            $('#CreateJoinCommunityModel').modal('show');
        });
    });
});

function getURLParameter(url, name) {
    return (RegExp(name + '=' + '(.+?)(&|$)').exec(url) || [, null])[1];
}