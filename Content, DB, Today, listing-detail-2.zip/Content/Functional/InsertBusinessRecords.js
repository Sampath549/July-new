﻿var opts = {
    "closeButton": true,
    "debug": false,
    "positionClass": "toast-top-full-width",
    "onclick": null,
    "showDuration": null,
    "hideDuration": null,
    "timeOut": null,
    "extendedTimeOut": null,
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
};

jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Enter Only Alphabets");

jQuery.validator.addMethod("numbersonly", function (value, element) {
    return this.optional(element) || /^[0-9]+$/i.test(value);
}, "Enter Only Numbers");

jQuery.validator.addMethod("selectNone", function (value, element) {
    return this.optional(element) || element.selectedIndex != 0;
}, "Please Select an Option");

$(document).ready(function () {

    var UploadedFileType;
    var FileExtention;
    var FileSize;
    var ImgData;

    $("#fileUpload").change(function (e) {
        if (!e) e = window.event;
        var file = e.target.files[0] || e.srcElement.files[0];
        //var filename = e.target.files[0].name;
        UploadedFileType = file.type;
        FileSize = file.size;

        if (file.type == "image/jpeg") {
            var fileReader = new FileReader();
            fileReader.onload = function (fileLoadedEvent) {
                FileExtention = ".jpg";
                ImgData = fileLoadedEvent.target.result;
            };
            fileReader.readAsDataURL(file);
        }
        else if (file.type == "image/png") {
            var fileReader = new FileReader();
            fileReader.onload = function (fileLoadedEvent) {
                FileExtention = ".png";
                ImgData = fileLoadedEvent.target.result;
            };
            fileReader.readAsDataURL(file);
        }
        else {
            toastr.error('Upload Images of Extentions .JPG, .JPEG, .PNG', 'Validation Error', opts);
            $("#fileUpload").val(null);
        }
    })

    $("#BusinessRecords").validate({
        rules: {
            'ClassifiedId': {
                selectNone: true
            },
            'Title': {
                required: true,
                minlength: 5,
                maxlength: 50
            },            
            'Address': {
                required: true,
                minlength: 3,
                maxlength: 50
            },
            'City': {
                required: true,
                minlength: 2,
                maxlength: 30
            },
            'StateId': {
                selectNone: true
            },
            'CountryId': {
                selectNone: true
            },
            'ZipCode': {
                required: true,
                numbersonly: true,
                maxlength: 5
            },
            'Description': {
                required: true,
                minlength: 3,
                maxlength: 300
            }
        },
        messages: {
            'Title': {
                required: 'Please Enter Title',
                minlength: 'Must enter Minimum of 5 characters'
            },
            'Address': {
                required: 'Please Enter Address',
                minlength: 'Must enter Minimum of 3 characters'
            },
            'City': {
                required: 'Please Enter City',
                minlength: 'Must enter Minimum of 2 characters'
            },
            'ZipCode': {
                required: 'Please Enter ZipCode'
            },
            'Description': {
                required: 'Please Enter Description'
            }
        },
        submitHandler: function () {
            $(".loadingImg").show();
            setTimeout(function () {

                var _postData = {
                    Title: $('#Title').val(),
                    ClassifiedId: $('#ClassifiedId').val(),
                    Address: $('#Address').val(),
                    City: $('#City').val(),
                    StateId: $('#StateId').val(),
                    CountryId: $('#CountryId').val(),
                    ZipCode: $('#ZipCode').val(),
                    Description: $('#Description').val(),
                    ImagePath: ImgData,
                    ImgType: FileExtention,
                    FileSize: FileSize
                };

                $.ajax({
                    type: "POST",
                    url: "/CPanelBusiness/InsertRecords",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        if (!response.Status) {
                            toastr.error(response.Message, response.Caption, opts);
                            $("#CreatePostModel").modal('show');
                        }
                        else {
                            $("#CreatePostModel").modal('hide');
                            swal({
                                title: response.Caption,
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    window.location.href = "/CPanelBusiness/Records?PageNum=1";
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        alert(xhr.responseText);
                    }
                });
            }, 0);
        }
    });
});