﻿var opts = {
    "closeButton": true,
    "debug": false,
    "positionClass": "toast-top-full-width",
    "onclick": null,
    "showDuration": null,
    "hideDuration": null,
    "timeOut": null,
    "extendedTimeOut": null,
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
};

jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Enter Only Alphabets");

jQuery.validator.addMethod("numbersonly", function (value, element) {
    return this.optional(element) || /^[0-9]+$/i.test(value);
}, "Enter Only Numbers");

jQuery.validator.addMethod("selectNone", function (value, element) {
    return this.optional(element) || element.selectedIndex != 0;
}, "Please Select an Option");

$(document).ready(function () {
    var ImgData = [];
    $("#fileBuySellPost").change(function (e) {
        if (!e) e = window.event;

        var i;
        if (e.target.files.length > 1) {
            toastr.error('Not more than 1 Images can be Uploaded', 'Validation Error', opts);
            $("#fileBuySellPost").val(null);
            ImgData = [];
        }
        else {
            for (i = 0; i < e.target.files.length; i++) {
                var file = e.target.files[i] || e.srcElement.files[i];

                if (file.type == "image/jpeg") {
                    var fileReader = new FileReader();
                    fileReader.onload = function (fileLoadedEvent) {
                        var obj = {
                            "ImagePath": fileLoadedEvent.target.result,
                            "ImgType": ".jpg",
                            "FileSize": file.size
                        };
                        ImgData.push(obj);
                    };
                    fileReader.readAsDataURL(file);
                }
                else if (file.type == "image/png") {
                    var fileReader = new FileReader();
                    fileReader.onload = function (fileLoadedEvent) {
                        var obj = {
                            "ImagePath": fileLoadedEvent.target.result,
                            "ImgType": ".png",
                            "FileSize": file.size
                        };
                        ImgData.push(obj);
                    };
                    fileReader.readAsDataURL(file);
                }
                else {
                    toastr.error('Upload Images of Extentions .JPG, .JPEG, .PNG', 'Validation Error', opts);
                    $("#fileBuySellPost").val(null);
                    ImgData = [];

                    break;
                }
            }
        }
    })

    $("#BuySellPostsDetails").validate({
        rules: {
            'Title': {
                required: true,
                minlength: 5,
                maxlength: 50
            },
            'City': {
                required: true,
                minlength: 2,
                maxlength: 30
            },
            'StateId': {
                selectNone: true
            },
            'CountryId': {
                selectNone: true
            },
            'ZipCode': {
                required: true,
                numbersonly: true,
                maxlength: 10
            },
            'Description': {
                required: true,
                minlength: 3,
                maxlength: 300
            }
        },
        messages: {
            'Title': {
                required: 'Please Enter Title',
                minlength: 'Must enter Minimum of 5 characters'
            },
            'City': {
                required: 'Please Enter City',
                minlength: 'Must enter Minimum of 2 characters'
            },
            'ZipCode': {
                required: 'Please Enter ZipCode'
            },
            'Description': {
                required: 'Please Enter Description'
            }
        },
        submitHandler: function () {
            $(".loadingImg").show();
            setTimeout(function () {
                var _postData = {
                    Title: $('#Title').val(),
                    DisplayMobile: $('input[name=DisplayMobile]:checked').val(),
                    City: $('#City').val(),
                    StateId: $('#StateId').val(),
                    CountryId: $('#CountryId').val(),
                    ZipCode: $('#ZipCode').val(),
                    Description: $('#Description').val(),
                    Images: ImgData
                };

                $.ajax({
                    type: "POST",
                    url: "/CPanelUser/InsertBuySellPosts",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        if (!response.Status) {
                            toastr.error(response.Message, response.Caption, opts);
                            $("#CreateBuySellPostsModel").modal('show');
                        }
                        else {
                            $("#CreateBuySellPostsModel").modal('hide');
                            swal({
                                title: response.Caption,
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    window.location.href = "/CPanelUser/BuySellPosts?PageNum=1";
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        alert(xhr.responseText);
                    }
                });
            }, 0);
        }
    });
});