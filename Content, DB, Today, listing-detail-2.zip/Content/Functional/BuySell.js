﻿$(document).ready(function () {
    $("#btnBuySellPostsRecord").click(function () {
        var url = $(this).data("url");
        $.get(url, function (data) {
            $('#CreateBuySellPostsData').html(data);
            $('#CreateBuySellPostsModel').modal('show');
        });
    });
});

function DeleteComent(BSID) {
    swal({
        title: "Are you sure?",
        text: "This will delete the Record",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Yes, Delete it!",
        closeOnConfirm: false
    },
      function (isConfirm) {
          $(".loadingImg").show();
          var url = $(location).attr("href");
          if (isConfirm) {
              $.ajax({
                  url: '/CPanelUser/DeleteBuySellPost',
                  type: 'POST',
                  data: { "DeleteBuySellPostID": BSID },
                  dataType: "json",
                  cache: false,
                  headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                  success: function (result) {
                      if (result.Status) {
                          swal("Deleted!", result.Message, "success");
                          setTimeout(window.location.href = '/CPanelUser/BuySellPosts?PageNum=1', 0);
                      }
                      else
                          swal("Cancelled!", result.Message, "error");
                  }
              });
          }
          $(".loadingImg").hide();
      }
)
}

function getURLParameter(url, name) {
    return (RegExp(name + '=' + '(.+?)(&|$)').exec(url) || [, null])[1];
}

