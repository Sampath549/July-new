﻿var opts = {
    "closeButton": true,
    "debug": false,
    "positionClass": "toast-top-full-width",
    "onclick": null,
    "showDuration": null,
    "hideDuration": null,
    "timeOut": null,
    "extendedTimeOut": null,
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
};

$(document).ready(function () {
    $("#PollsDetails").validate({
        rules: {
            'Title': {
                required: true,
                minlength: 5,
                maxlength: 50
            },
            'Question': {
                required: true,
                minlength: 3,
                maxlength: 300
            }
        },
        messages: {
            'Title': {
                required: 'Please Enter Title',
                minlength: 'Must enter Minimum of 5 characters'
            },
            'Question': {
                required: 'Please Enter Poll Question'
            }
        },
        submitHandler: function () {
            $(".loadingImg").show();
            setTimeout(function () {

                var _postData = {
                    Title: $('#Title').val(),
                    Question: $('#Question').val()
                };

                $.ajax({
                    type: "POST",
                    url: "/CPanelCommunity/InsertPolls",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        if (!response.Status) {
                            toastr.error(response.Message, response.Caption, opts);
                            $("#CreateAddPollsModel").modal('show');
                        }
                        else {
                            $("#CreateAddPollsModel").modal('hide');
                            swal({
                                title: response.Caption,
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    window.location.href = "/CPanelCommunity/Polls";
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        alert(xhr.responseText);
                    }
                });
            }, 0);
        }
    });
});