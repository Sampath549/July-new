﻿var opts = {
    "closeButton": true,
    "debug": false,
    "positionClass": "toast-top-full-width",
    "onclick": null,
    "showDuration": null,
    "hideDuration": null,
    "timeOut": null,
    "extendedTimeOut": null,
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
};

$(document).ready(function () {
    $("#fileEvents").change(function (e) {
        if (!e) e = window.event;

        var i;
        if (e.target.files.length > 5) {
            toastr.error('Not more than 5 Images can be Uploaded', 'Validation Error', opts);
            $("#fileEvents").val(null);
        }
        else {
            for (i = 0; i < e.target.files.length; i++) {
                var file = e.target.files[i] || e.srcElement.files[i];

                var _lst = ["image/jpeg", "image/jpg", "image/png"];
                var val = _lst.includes(file.type);

                if (val == false) {
                    toastr.error('Upload Images of Extentions .JPG, .JPEG, .PNG', 'Validation Error', opts);
                    $("#fileEvents").val(null);
                    break;
                }
            }
        }
    })

    $("#EventsDetails").validate({
        rules: {
            'Title': {
                required: true,
                minlength: 5,
                maxlength: 50
            },
            'Description': {
                required: true,
                minlength: 3,
                maxlength: 300
            },
            'fileEvents': {
                required: true
            }
        },
        messages: {
            'Title': {
                required: 'Please Enter Title',
                minlength: 'Must enter Minimum of 5 characters'
            },
            'Description': {
                required: 'Please Enter Description'
            },
            'fileEvents': {
                required: 'Please Upload atleast one File'
            }
        },
        submitHandler: function () {
            $(".loadingImg").show();
            setTimeout(function () {

                var fileUpload = $("#fileEvents").get(0);
                var files = fileUpload.files;

                var fileData = new FormData();
                for (var i = 0; i < files.length; i++) {
                    console.log(files[i].name)
                    fileData.append(files[i].name, files[i]);
                }

                fileData.append('Title', $('#Title').val())
                fileData.append('Description', $('#Description').val())

                $.ajax({
                    type: "POST",
                    url: "/CPanelCommunity/InsertEvents",
                    data: fileData,
                    dataType: "json",
                    contentType: false, // Not to set any content header  
                    processData: false, // Not to process data 
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        if (!response.Status) {
                            toastr.error(response.Message, response.Caption, opts);
                            $("#CreateAddEventsModel").modal('show');
                        }
                        else {
                            $("#CreateAddEventsModel").modal('hide');
                            swal({
                                title: response.Caption,
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    window.location.href = "/CPanelCommunity/Events";
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        alert(xhr.responseText);
                    }
                });
            }, 0);
        }
    });
});