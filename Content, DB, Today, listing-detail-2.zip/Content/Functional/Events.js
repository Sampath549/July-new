﻿var opts = {
    "closeButton": true,
    "debug": false,
    "positionClass": "toast-top-full-width",
    "onclick": null,
    "showDuration": null,
    "hideDuration": null,
    "timeOut": null,
    "extendedTimeOut": null,
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
};

$(document).ready(function () {

    GetTable();

    $("#btnAddRecord").click(function () {
        var url = $(this).data("url");
        $.get(url, function (data) {
            $('#CreateAddEventsData').html(data);
            $('#CreateAddEventsModel').modal('show');
        });
    });
});

function GetTable() {
    Table = $('#tblEvents').DataTable({
        "processing": true,
        "serverSide": false,
        "paging": true,
        "ordering": true,
        "info": true,
        "searching": true,
        "bFilter": false,
        "scrollX": "100%",
        "scrollY": ($(window).height() - 500),
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "ajax": {
            "type": "POST",
            "url": "/CPanelCommunity/GetEvents",
            "dataSrc": function (data, type, row) {
                if (data.isRedirect)
                    window.location.href = data.URL;
                else
                    return data.aaData;
            }
        },
        "bDestroy": true,
        "bLengthChange": true,
        "bPaginate": true,
        "sEmptyTable": "Loading data from server",
        "columns": [
            { "sWidth": "5%", "sClass": "DisabelDTColumn EventId", "render": function (data, type, row) { return row[0]; } },
            { "sClass": "TextCenter Title", "render": function (data, type, row) { return (row[1]); } },
            { "sWidth": "25%", "sClass": "text-align-center DateLongString", "render": function (data, type, row) { return (row[2]); } },
            {
                "sWidth": "10%",
                "bSortable": false,
                "sClass": "TextCenter",
                "render": function (data, type, row) {
                    return '<center><a href="javascript:void(0);" title="View" onclick=ViewData("' + row[0] + '"); return false;> <i class="fa fa-eye"></i></a></center>';
                }, "targets": 0,
            }
        ],
    });
}

function ViewData(code) {
    window.location.href = "/CPanelCommunity/ViewEvent?Id=" + code
}

function getURLParameter(url, name) {
    return (RegExp(name + '=' + '(.+?)(&|$)').exec(url) || [, null])[1];
}