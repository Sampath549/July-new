﻿$(document).ready(function () {
    GetTable();
});

function GetTable() {
    Table = $('#tblGetAccReq').DataTable({
        "processing": true,
        "serverSide": false,
        "paging": true,
        "ordering": true,
        "info": true,
        "searching": true,
        "bFilter": false,
        "scrollX": "100%",
        "scrollY": ($(window).height() - 500),
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "ajax": {
            "type": "POST",
            "url": "/CPanelUser/GetAccRequests",
            "dataSrc": function (data, type, row) {
                if (data.isRedirect)
                    window.location.href = data.URL;
                else
                    return data.aaData;
            }
        },
        "bDestroy": true,
        "bLengthChange": true,
        "bPaginate": true,
        "sEmptyTable": "Loading data from server",
        "columns": [
            { "sWidth": "5%", "sClass": "DisabelDTColumn AccommodationId", "render": function (data, type, row) { return row[0]; } },
            { "sClass": "TextCenter Name", "render": function (data, type, row) { return (row[1]); } },
            { "sWidth": "15%", "sClass": "text-align-center TotalComments", "render": function (data, type, row) { return (row[2]); } },
            {
                "sWidth": "10%",
                "bSortable": false,
                "sClass": "TextCenter",
                "render": function (data, type, row) {
                    return '<center><a href="javascript:void(0);" title="View" onclick=ViewData("' + row[0] + '"); return false;> <i class="fa fa-eye"></i></a></center>';
                }, "targets": 0,
            }
        ],
    });
}

function ViewData(code) {
    window.location.href = "/CPanelUser/ViewAccRequests?Id=" + code
}