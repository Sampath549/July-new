﻿var opts = {
    "closeButton": true,
    "debug": false,
    "positionClass": "toast-top-full-width",
    "onclick": null,
    "showDuration": null,
    "hideDuration": null,
    "timeOut": null,
    "extendedTimeOut": null,
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
};

$(document).ready(function () {

    GetTable();

    $("#btnAddRecord").click(function () {
        var url = $(this).data("url");
        $.get(url, function (data) {
            $('#CreateAddPollsData').html(data);
            $('#CreateAddPollsModel').modal('show');
        });
    });
});

function GetTable() {
    Table = $('#tblPolls').DataTable({
        "processing": true,
        "serverSide": false,
        "paging": true,
        "ordering": true,
        "info": true,
        "searching": true,
        "bFilter": false,
        "scrollX": "100%",
        "scrollY": ($(window).height() - 500),
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "ajax": {
            "type": "POST",
            "url": "/CPanelCommunity/GetPolls",
            "dataSrc": function (data, type, row) {
                if (data.isRedirect)
                    window.location.href = data.URL;
                else
                    return data.aaData;
            }
        },
        "bDestroy": true,
        "bLengthChange": true,
        "bPaginate": true,
        "sEmptyTable": "Loading data from server",
        "columns": [
            { "sWidth": "1%", "sClass": "DisabelDTColumn PollId", "render": function (data, type, row) { return row[0]; } },
            { "sWidth": "30%", "sClass": "TextCenter Title", "render": function (data, type, row) { return (row[1]); } },
            { "sClass": "TextCenter Question", "render": function (data, type, row) { return (row[2]); } },
            { "sWidth": "6%", "sClass": "TextCenter YesPercentage", "render": function (data, type, row) { return (row[3]); } },
            { "sWidth": "6%", "sClass": "TextCenter NoPercentage", "render": function (data, type, row) { return (row[4]); } },
            { "sWidth": "15%", "sClass": "text-align-center DateLongString", "render": function (data, type, row) { return (row[5]); } },
            {
                "sWidth": "5%",
                "bSortable": false,
                "sClass": "TextCenter",
                "render": function (data, type, row) {
                    return '<center><a href="javascript:void(0);" title="View" onclick=ViewData("' + row[0] + '"); return false;> <i class="fa fa-eye"></i></a></center>';
                }, "targets": 0,
            }
        ],
    });
}

function getURLParameter(url, name) {
    return (RegExp(name + '=' + '(.+?)(&|$)').exec(url) || [, null])[1];
}