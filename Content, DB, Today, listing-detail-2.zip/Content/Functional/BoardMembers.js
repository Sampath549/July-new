﻿var opts = {
    "closeButton": true,
    "debug": false,
    "positionClass": "toast-top-full-width",
    "onclick": null,
    "showDuration": null,
    "hideDuration": null,
    "timeOut": null,
    "extendedTimeOut": null,
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
};

$(document).ready(function () {
    $("#btnAddRecord").click(function () {
        var url = $(this).data("url");
        $.get(url, function (data) {
            $('#CreateAddBMembersData').html(data);
            $('#CreateAddBMembersModel').modal('show');
        });
    });
});

function getURLParameter(url, name) {
    return (RegExp(name + '=' + '(.+?)(&|$)').exec(url) || [, null])[1];
}