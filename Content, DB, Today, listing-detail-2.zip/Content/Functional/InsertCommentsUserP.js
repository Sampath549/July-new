﻿$(document).ready(function () {
    $("#CommentDetailsUserP").validate({
        rules: {
            txtComments: {
                required: true,
                minlength: 3,
                maxlength: 500
            }
        },
        messages: {
            txtComments: {
                required: 'Please Enter Comments',
                minlength: 'Must enter Minimum of 3 characters'
            }
        },
        submitHandler: function (form) {
            $(".loadingImg").show();
            var url = $(location).attr("href");
            var _PageColumnId = getURLParameter(url, 'Id'); // calling another function
            setTimeout(function () {
                $.ajax({
                    type: "POST",
                    url: "/User/InsertComments",
                    data: { "Comments": $("#txtComments").val(), "PageColumnId": _PageColumnId, "PageId": form.title },
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
                        console.log(response);
                        if (!response.Status) {
                            toastr.error(response.Message, response.Caption, opts);
                        }
                        else {
                            swal({
                                title: response.Caption,
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            }, function (isConfirm) {
                                if (isConfirm) {
                                    window.location.href = url;
                                }
                            }
                            );
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        alert(xhr.responseText);
                    }
                });
            }, 0);
        }
    });
    $('.hrefLinkClick').click(function (e) {
        e.preventDefault();
    });

});

function getURLParameter(url, name) {
    return (RegExp(name + '=' + '(.+?)(&|$)').exec(url) || [, null])[1];
}

function MyFunc(val) {
    $("#" + val).empty();
    var div = GetDynamicTextBox(val, "");
    $("#" + val).append(div);
}

function GetDynamicTextBox(val, value) {
    var div = $("<div />");

    var textArea = $("<textarea />").attr("class", "form-control").attr("rows", "4").attr("id", "DynamicTextBox" + val).attr("name", "DynamicTextBox" + val).attr("placeholder", "Comment");
    textArea.val(value);
    div.append(textArea);

    var button2 = $("<input />").attr("type", "submit").attr("class", "btn btn-primary btnWidth120").attr("style", "float:right;margin: 0px 10px 0px 0px !important").attr("value", "Send Reply");
    button2.attr("onclick", "SendReply(" + val + ")");
    div.append(button2);

    var button1 = $("<input />").attr("type", "submit").attr("class", "btn btn-default btnWidth btnBorder").attr("style", "float:right; margin: 0px 10px 0px 0px !important").attr("value", "Close");
    button1.attr("onclick", "RemoveTextBox(this)");
    div.append(button1);

    return div;
}

function SendReply(ParentCommentID) {
    $(".loadingImg").show();
    var url = $(location).attr("href");
    var _PageId = url.split("/")[4].split("?")[0].split("View")[1];
    var _PageColumnId = getURLParameter(url, 'Id'); // calling another function
    alert(_PageColumnId)
    setTimeout(function () {
        $.ajax({
            type: "POST",
            url: "/User/InsertReplyComments",
            data: { "Comments": $("#DynamicTextBox" + ParentCommentID).val(), "PageColumnId": _PageColumnId, "PageId": _PageId, "ParentCommentId": ParentCommentID },
            dataType: "json",
            cache: false,
            headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
            success: function (response) {
                var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
                console.log(response);
                if (!response.Status) {
                    toastr.error(response.Message, response.Caption, opts);
                }
                else {
                    swal({
                        title: response.Caption,
                        text: response.Message,
                        type: "success",
                        confirmButtonText: "OK"
                    }, function (isConfirm) {
                        if (isConfirm) {
                            window.location.href = url;
                        }
                    }
                    );
                }
                $(".loadingImg").hide();
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.responseText);
            }
        });
    }, 0);
}

function RemoveTextBox(button) {
    $(button).parent().remove();
}