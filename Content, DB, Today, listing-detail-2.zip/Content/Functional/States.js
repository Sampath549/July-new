﻿$(document).ready(function () {
    GetTable();

    $("#btnStatesRecord").click(function () {
        var url = $(this).data("url");
        $.get(url, function (data) {
            $('#CreateStatesData').html(data);
            $('#CreateStatesModel').modal('show');
        });
    });

    $('#tblGetStates').on("click", ".editStates", function (event) {
        event.preventDefault();
        var url = $(this).attr("href");
        $.get(url, function (data) {
            $('#EditStatesData').html(data);
            $('#EditStatesModel').modal('show');
        });
    });

    $('#tblGetStates').on("click", ".deleteStates", function (event) {
        event.preventDefault();
        var url = $(this).attr("href");
        var id = getURLParameter(url, 'id'); // calling another function

        swal({
            title: "Are you sure?",
            text: "This will delete the Record",
            type: "warning",
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, Delete it!",
            closeOnConfirm: false
        },
        function (isConfirm) {
            $(".loadingImg").show();
            if (isConfirm) {
                $.ajax({
                    url: '/CPanelDev/DeleteStates',
                    type: 'POST',
                    data: JSON.stringify({ "IdVal": id }),
                    contentType: 'application/json; charset=utf-8;',
                    success: function (result) {
                        if (result.Status) {
                            swal("Deleted!", result.Message, "success");
                            GetTable();
                        }
                        else
                            swal("Cancelled!", result.Message, "error");
                    }
                });
            }
            $(".loadingImg").hide();
        }
    );
    });
});

function getURLParameter(url, name) {
    return (RegExp(name + '=' + '(.+?)(&|$)').exec(url) || [, null])[1];
}

function GetTable() {
    Table = $('#tblGetStates').DataTable({
        "processing": true,
        "serverSide": false,
        "paging": true,
        "ordering": true,
        "info": true,
        "searching": true,
        "bFilter": false,
        "scrollX": "100%",
        "scrollY": ($(window).height() - 500),
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "sAjaxSource": '/CPanelDev/GetStatesGrid',
        "bDestroy": true,
        "bLengthChange": true,
        "bPaginate": true,
        "sEmptyTable": "Loading data from server",

        "columns": [
            { "visible": false, "sWidth": "10%", "sClass": "TextCenter StateId", "render": function (data, type, row) { return row[0]; } },
            { "visible": false, "sWidth": "10%", "sClass": "TextCenter CountryId", "render": function (data, type, row) { return row[1]; } },
            { "sWidth": "35%", "sClass": "TextCenter CountryName", "render": function (data, type, row) { return row[2]; } },
            { "sWidth": "20%", "sClass": "TextCenter Code", "render": function (data, type, row) { return (row[3]); } },
            { "sWidth": "35%", "sClass": "TextCenter Description", "render": function (data, type, row) { return (row[4]); } },
            {
                "sWidth": "10%",
                "bSortable": false,
                "sClass": "TextCenter",
                "render": function (data, type, row) {
                    return '<center><a href="/CPanelDev/EditStates?id=' + row[0] + '"  class="editStates" title="Edit" return false;> <i class="glyphicon glyphicon-edit"></i></a>&nbsp;&nbsp;<a href="/CPanelDev/DeleteStates?id=' + row[0] + '" class="deleteStates" title="Delete" return false;> <i class="glyphicon glyphicon-trash"></i></a>&nbsp;&nbsp;</center>';
                }, "targets": 0,
            }
        ],
    });
}