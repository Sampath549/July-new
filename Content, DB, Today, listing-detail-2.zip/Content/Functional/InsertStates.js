﻿jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Enter Only Alphabets");

jQuery.validator.addMethod("numbersonly", function (value, element) {
    return this.optional(element) || /^[0-9]+$/i.test(value);
}, "Enter Only Numbers");

jQuery.validator.addMethod("selectNone", function (value, element) {
    return this.optional(element) || element.selectedIndex != 0;
}, "Please select an Option");

$(document).ready(function () {
    $("#StatesDetails").validate({
        rules: {
            'CountryId': {
                selectNone: true
            },
            'Code': {
                required: true,
                minlength: 2,
                lettersonly: true
            },
            'Description': {
                required: true,
                minlength: 2,
                lettersonly: true
            }
        },
        messages: {
            'CountryId': {
                selectNone: 'Please Select Country'
            },
            'Code': {
                required: 'Enter Code.',
                minlength: 'Must enter Minimum of 2 characters'
            },
            'Description': {
                required: 'Enter Description.',
                minlength: 'Must enter Minimum of 2 characters'
            }
        },
        submitHandler: function () {
            $(".loadingImg").show();

            var _postData;
            if ($('#btnStates').val() == 'Save') {
                _postData = {
                    CountryId: $('#CountryId').val(),
                    Code: $('#Code').val(),
                    Description: $('#Description').val()
                };
            }
            else if ($('#btnStates').val() == 'Update') {
                _postData = {
                    Id: $('#Id').val(),
                    CountryId: $('#CountryId').val(),
                    Code: $('#Code').val(),
                    Description: $('#Description').val()
                };
            }

            console.log(_postData);
            $.ajax({
                type: "POST",
                url: "/CPanelDev/InsertUpdateStates",
                data: _postData,
                dataType: "json",
                cache: false,
                headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                success: function (response) {
                    var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
                    if (!response.Status) {
                        toastr.error(response.Message, response.Caption, opts);
                        $("#CreateStatesModel").modal('show');
                    }
                    else {
                        $("#CreateStatesModel").modal('hide');
                        swal({
                            title: response.Caption,
                            text: response.Message,
                            type: "success",
                            confirmButtonText: "OK"
                        },
                        function (isConfirm) {
                            if (isConfirm) {
                                window.location.href = "/CPanelDev/CreateStates";
                            }
                        });
                    }

                    $(".loadingImg").hide();
                }
            });
        }
    });
});