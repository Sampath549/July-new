USE [EuroBharat]

CREATE TABLE [Ref_Roles]
(
[RoleId]		INT				NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
[ModifiedDate]	DATETIME		NULL,
CONSTRAINT PK_RefRoleId PRIMARY KEY ([RoleId]),
CONSTRAINT UC_RefRoleCode UNIQUE ([Code])
)

INSERT [Ref_Roles] ([Code], [Description]) VALUES ('DEV', 'Developer')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('SA', 'Super Admin')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('ADM', 'Admin')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('USR', 'User')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('BUS', 'Business')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('COMM', 'Community')

----- END -----

CREATE TABLE [Ref_Countries]
(
[CountryId]		INT				NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
[ModifiedDate]	DATETIME		NULL,
CONSTRAINT PK_CountryId PRIMARY KEY ([CountryId]),
CONSTRAINT UC_CountryCodeDesc UNIQUE ([Code],[Description])
)

INSERT [Ref_Countries] ([Code], [Description]) VALUES ('GER', 'Germany')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('HUN', 'Hungary')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('POL', 'Poland')

----- END -----

CREATE TABLE [Ref_States]
(
[StateId]		INT				NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CountryId]		INT				NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
[ModifiedDate]	DATETIME		NULL,
CONSTRAINT PK_StateId PRIMARY KEY ([StateId]),
CONSTRAINT FK_CState FOREIGN KEY ([CountryId]) REFERENCES [Ref_Countries]([CountryId]),
CONSTRAINT UC_StateCodeDesc UNIQUE ([Code],[Description])
)

INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('BER', 'Berlin', 1)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('HAM', 'Hamburg', 1)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('SAA', 'Saarland', 1)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('BUD', 'Budapest', 2)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('FEJ', 'Fejer', 2)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('NOG', 'Nograd', 2)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('WAR', 'Warsaw', 3)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('OPO', 'Opole', 3)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('MAS', 'Masovian', 3)

----- END -----

CREATE TABLE [Ref_Classifieds]
(
[ClassifiedId]		INT				NOT NULL IDENTITY(1,1),
[Code]				VARCHAR(5)		NOT NULL,
[Description]		VARCHAR(100)	NOT NULL,
[CreatedDate]		DATETIME		DEFAULT GETDATE(),
[ModifiedDate]		DATETIME		NULL,
CONSTRAINT PK_ClassifiedId PRIMARY KEY ([ClassifiedId]),
CONSTRAINT UC_ClaCodeDesc UNIQUE ([Code],[Description])
)

INSERT [Ref_Classifieds] ([Code], [Description]) VALUES ('REST', 'Real Estate')
INSERT [Ref_Classifieds] ([Code], [Description]) VALUES ('FOOD', 'Restaurant')
INSERT [Ref_Classifieds] ([Code], [Description]) VALUES ('HELFI', 'Health & Fitness')
INSERT [Ref_Classifieds] ([Code], [Description]) VALUES ('BESPA', 'Beauty & Spas')
INSERT [Ref_Classifieds] ([Code], [Description]) VALUES ('HOTRA', 'Hotels & Travels')
INSERT [Ref_Classifieds] ([Code], [Description]) VALUES ('AUTO', 'Automotive')

----- END -----