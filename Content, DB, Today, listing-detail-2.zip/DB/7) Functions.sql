--USE [EuroBharat]

CREATE FUNCTION [TotalCommentsCount]  
(  
       @UID INT,  
	   @PageId	INT,
       @PageColumnId INT 
)  
RETURNS int  
AS  
BEGIN  
	DECLARE @Result INT 
	DECLARE @PostedUser INT

	IF(@PageId = 1)
		SET @PostedUser = (SELECT UserId FROM [EuroDB].[tbl_AccommodationPosts] WHERE [AccommodationPostId] = @PageColumnId)

	IF(@PageId = 2)
		SET @PostedUser = (SELECT UserId FROM [EuroDB].[tbl_BuySellPosts] WHERE [BuySellPostId] = @PageColumnId)

	IF(@PageId = 3)
		SET @PostedUser = (SELECT UserId FROM [EuroDB].[tbl_Business] WHERE [BusinessId] = @PageColumnId)

	DECLARE @ActualCount INT = (SELECT COUNT(*) FROM [EuroDB].[tbl_Comments] WHERE PageId = @PageId AND PageColumnId = @PageColumnId AND UserId = @UID AND ParentCommentId = 0)
	DECLARE @tblSub		TABLE (CommentId INT, UserId INT, PageId INT, PageColumnId INT, Comments VARCHAR(800), ParentCommentId INT, HavingParentCommentId BIT, CommentedDate DATETIME)

	INSERT INTO @tblSub
	SELECT * FROM [EuroDB].[tbl_Comments] WHERE PageId = @PageId AND PageColumnId = @PageColumnId AND UserId = @UID AND ParentCommentId = 0
	UNION
	SELECT * FROM [EuroDB].[tbl_Comments] WHERE PageId = @PageId AND PageColumnId = @PageColumnId AND UserId IN (@UID,@PostedUser) AND HavingParentCommentId > 0 AND ParentCommentId > 0

	SELECT @Result = (@ActualCount + (SELECT COUNT(*) FROM @tblSub A INNER JOIN @tblSub S ON A.CommentId = S.ParentCommentId))

    RETURN @Result
END

--SELECT dbo.[TotalCommentsCount](2,1,3) AS 'Count'

----- END -----