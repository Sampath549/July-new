USE [EuroBharat]

CREATE TYPE [BuySellImages] AS TABLE(
	[ImgId] [int],
	[ImagePath] [varchar](max) NULL,
	[ImgType] [varchar](10) NULL
)

----- END -----

CREATE TYPE [UserIds] AS TABLE(
	[Id] [int],
	[UserId] [int]
)

----- END -----

CREATE TYPE [EventsGallery] AS TABLE(
	[ImgId] [int],
	[ImagePath] [varchar](max) NULL,
	[ImgType] [varchar](10) NULL
)

----- END -----
