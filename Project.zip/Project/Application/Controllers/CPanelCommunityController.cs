﻿using Application.App_Start;
using Application.Filters;
using Application.Helper;
using Application.Models.SharedEntities;
using Microsoft.Security.Application;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.Controllers
{
    [MVCSessionFilter, MultiLoginFilter, MVCCommunityAuthorization]
    public class CPanelCommunityController : Controller
    {
        #region Global Variables & Default Constructor
        public SE_Users _SessionUserDetails;
        public CPanelCommunityController()
        {
            ViewBag.DisplayModalPopup = Reusable.CheckIsFirstTimeLogin();   // Model PopUp   
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
        }
        #endregion

        #region Dashboard
        public ActionResult Dashboard()
        {
            try
            {
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }
        #endregion

        #region Board Members
        public ActionResult BoardMembers()
        {
            try
            {
                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(_SessionUserDetails.UserId.ToString());

                string response = ApiHelper.PostData_Json("api/CPanelCommunity/GridBMembers?Values=", _Array);
                Result<List<SE_BMembers>> _Result = JsonConvert.DeserializeObject<Result<List<SE_BMembers>>>(response);
                return View(_Result.Data[0]);
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }
        public ActionResult AddBMembers()
        {
            try
            {
                ViewBag.AllUsers = Reusable.AllUsersList();
                return View("../PartialViews/AddBMembers");
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertBMembers(SE_BMembers _Records)
        {
            try
            {
                //Server-Side Validations
                if (_Records.UserIds.Count == 0)
                    return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);

                _Records.CUserId = _SessionUserDetails.UserId;

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Records);
                string response = ApiHelper.PostData_Json("api/CPanelCommunity/InsertBMembers?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<bool>(false, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Community Users
        public ActionResult CommunityUsers()
        {
            try
            {
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }
        #endregion

        #region Polls
        public ActionResult Polls()
        {
            try
            {
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        public JsonResult GetPolls()
        {
            List<SE_Polls> _list = new List<SE_Polls>();
            try
            {
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_SessionUserDetails.UserId.ToString());

                string response = ApiHelper.PostData_Json("api/CPanelCommunity/GetPolls?Values=", _Array);
                Result<List<SE_Polls>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Polls>>>(response);
                _list = _Result.Data;

                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString( c.PollId ),          // 0   
                                 Convert.ToString( c.Title ),           // 1   
                                 Convert.ToString( c.Question),         // 2   
                                 Convert.ToString( c.YesPercentage),    // 3   
                                 Convert.ToString( c.NoPercentage),     // 4   
                                 Convert.ToString( c.DateLongString),   // 5    
                             };

                return Json(new { aaData = result, URL = "", isRedirect = false }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<bool>(false, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult AddPolls()
        {
            try
            {
                return View("../PartialViews/AddPolls");
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertPolls(SE_Polls _Records)
        {
            try
            {
                //Server-Side Validations
                if (_Records.Title == null || Sanitizer.GetSafeHtmlFragment(_Records.Title) == "" || Sanitizer.GetSafeHtmlFragment(_Records.Title).Length > 50 || Sanitizer.GetSafeHtmlFragment(_Records.Title).Length < 5)
                    return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);
                if (_Records.Question == null || Sanitizer.GetSafeHtmlFragment(_Records.Question) == "" || Sanitizer.GetSafeHtmlFragment(_Records.Question).Length > 300 || Sanitizer.GetSafeHtmlFragment(_Records.Question).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);

                _Records.UserId = _SessionUserDetails.UserId;

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Records);
                string response = ApiHelper.PostData_Json("api/CPanelCommunity/InsertPolls?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<bool>(false, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Events
        public ActionResult Events()
        {
            try
            {
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        public JsonResult GetEvents()
        {
            List<SE_Events> _list = new List<SE_Events>();
            try
            {
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_SessionUserDetails.UserId.ToString());

                string response = ApiHelper.PostData_Json("api/CPanelCommunity/GetEvents?Values=", _Array);
                Result<List<SE_Events>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Events>>>(response);
                _list = _Result.Data;

                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString( c.EventId ),    // 0   
                                 Convert.ToString( c.Title ),        // 1   
                                 Convert.ToString( c.DateLongString), // 2     
                             };

                return Json(new { aaData = result, URL = "", isRedirect = false }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<bool>(false, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult ViewEvent(int Id)
        {
            try
            {
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_SessionUserDetails.UserId.ToString());
                _Array.Add(Id.ToString());

                string response = ApiHelper.PostData_Json("api/CPanelCommunity/SingleEvent?Values=", _Array);
                Result<SE_Events> _Result = JsonConvert.DeserializeObject<Result<SE_Events>>(response);
                _Result.Data.ConfigUrl = GlobalVariables.Shared.ConfigUrl;

                return View(_Result.Data);
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        public ActionResult AddEvents()
        {
            try
            {
                return View("../PartialViews/AddEvents");
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertEvents()
        {
            SE_Events _Records = new SE_Events();
            try
            {
                _Records.Title = Request.Form["Title"];
                _Records.Description = Request.Form["Description"];
                _Records.Images = new List<SE_EventImages>();
                _Records.UserId = _SessionUserDetails.UserId;

                HttpFileCollectionBase _files = Request.Files;
                for (int i = 0; i < _files.Count; i++)
                {
                    HttpPostedFileBase file = _files[i];
                    SE_EventImages _Img = new SE_EventImages();
                    _Img.ImagePath = "AccessFolders/EventsUploads/" + _Records.Title + "/" + (i + 1) + Path.GetExtension(file.FileName);
                    _Img.ImgType = file.ContentType;
                    _Records.Images.Add(_Img);
                }

                //Server-Side Validations
                if (_Records.Title == null || Sanitizer.GetSafeHtmlFragment(_Records.Title) == "" || Sanitizer.GetSafeHtmlFragment(_Records.Title).Length > 50 || Sanitizer.GetSafeHtmlFragment(_Records.Title).Length < 5)
                    return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);
                if (_Records.Description == null || Sanitizer.GetSafeHtmlFragment(_Records.Description) == "" || Sanitizer.GetSafeHtmlFragment(_Records.Description).Length > 300 || Sanitizer.GetSafeHtmlFragment(_Records.Description).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);
                if (_Records.Images.Count != 0)
                {
                    List<string> _ext = Reusable.EventsExtentions();
                    for (int c = 0; c < _Records.Images.Count; c++)
                        if (!_ext.Contains(_Records.Images[c].ImgType))
                            return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);
                }

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Records);
                string response = ApiHelper.PostData_Json("api/CPanelCommunity/InsertEvents?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                if (_Result.Status)
                {
                    string _SubFolder = System.Web.HttpContext.Current.Server.MapPath("~/AccessFolders/EventsUploads/" + _Records.Title);
                    if (!Directory.Exists(_SubFolder))
                        Directory.CreateDirectory(_SubFolder);

                    for (int i = 0; i < _files.Count; i++)
                    {
                        HttpPostedFileBase file = _files[i];
                        string fname;
                        string fileExt = Path.GetExtension(file.FileName);

                        // Checking for Internet Explorer  
                        if (Request.Browser.Browser.ToUpper() == "IE" || Request.Browser.Browser.ToUpper() == "INTERNETEXPLORER")
                        {
                            string[] testfiles = file.FileName.Split(new char[] { '\\' });
                            fname = testfiles[testfiles.Length - 1];
                        }
                        else
                            fname = file.FileName;

                        fname = Path.Combine(Server.MapPath("~/AccessFolders/EventsUploads/" + _Records.Title), (i + 1) + fileExt);
                        file.SaveAs(fname);
                    }
                    return Json(_Result, JsonRequestBehavior.AllowGet);
                }
                else
                    return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<bool>(false, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion
    }
}