﻿using Application.App_Start;
using Application.Filters;
using Application.Helper;
using Application.Models.SharedEntities;
using Microsoft.Security.Application;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.Controllers
{
    [MVCSessionFilter, MultiLoginFilter, MVCUserAuthorization]
    public class UserController : Controller
    {
        #region Global Variables & Default Constructor
        public SE_Users _SessionUserDetails;
        public UserController()
        {
            _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
        }
        #endregion

        #region Home
        public ActionResult Home()
        {
            ViewBag.AllowedBrowser = Reusable.BrowserCheck(Request.Browser.Browser); // Checking Browser
            return View();
        }
        #endregion

        #region Accommodation
        public ActionResult Accommodation(int? PageNum)
        {
            ViewBag.AllowedBrowser = Reusable.BrowserCheck(Request.Browser.Browser); // Checking Browser

            //API Call		
            ArrayList _Array = new ArrayList();
            _Array.Add(Convert.ToString(PageNum == null ? 1 : PageNum));
            _Array.Add(_SessionUserDetails.UserId.ToString());

            string response = ApiHelper.PostData_Json("api/UserPresentation/GridAccPosts?Values=", _Array);
            Result<List<SE_Accommodation>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Accommodation>>>(response);
            List_SE_Accommodation _lst = new List_SE_Accommodation();
            _lst.ListAccPosts = _Result.Data;
            return View(_lst);
        }
        public ActionResult ViewAccPost(int Id)
        {
            ViewBag.AllowedBrowser = Reusable.BrowserCheck(Request.Browser.Browser); // Checking Browser

            //API Call		
            ArrayList _Array = new ArrayList();
            _Array.Add(_SessionUserDetails.UserId.ToString());
            _Array.Add(Id.ToString());

            string response = ApiHelper.PostData_Json("api/UserPresentation/SingleAccPosts?Values=", _Array);
            Result<ViewPost_Comments> _Result = JsonConvert.DeserializeObject<Result<ViewPost_Comments>>(response);
            ViewPost_Comments _Data = _Result.Data;
            _Data.RawHTML = Reusable.RawHTMLComments(_Result.Data.CommentsList);
            return View(_Data);
        }
        #endregion

        #region BuySell
        public ActionResult BuySell(int? PageNum)
        {
            ViewBag.AllowedBrowser = Reusable.BrowserCheck(Request.Browser.Browser); // Checking Browser

            //API Call		
            ArrayList _Array = new ArrayList();
            _Array.Add(Convert.ToString(PageNum == null ? 1 : PageNum));
            _Array.Add(_SessionUserDetails.UserId.ToString());

            string response = ApiHelper.PostData_Json("api/UserPresentation/GridBuySellPosts?Values=", _Array);
            Result<List<SE_BuySell>> _Result = JsonConvert.DeserializeObject<Result<List<SE_BuySell>>>(response);
            List_SE_BuySell _lst = new List_SE_BuySell();
            _lst.ListBuySellPosts = _Result.Data;
            return View(_lst);
        }
        public ActionResult ViewBuySellPost(int Id)
        {
            ViewBag.AllowedBrowser = Reusable.BrowserCheck(Request.Browser.Browser); // Checking Browser

            //API Call		
            ArrayList _Array = new ArrayList();
            _Array.Add(_SessionUserDetails.UserId.ToString());
            _Array.Add(Id.ToString());

            string response = ApiHelper.PostData_Json("api/UserPresentation/SingleBSPosts?Values=", _Array);
            Result<ViewBSPost_Comments> _Result = JsonConvert.DeserializeObject<Result<ViewBSPost_Comments>>(response);
            ViewBSPost_Comments _Data = _Result.Data;
            _Data.RawHTML = Reusable.RawHTMLComments(_Result.Data.CommentsList);
            return View(_Data);
        }
        #endregion

        #region Business
        public ActionResult Classifieds(int? PageNum, string ClassifiedName)
        {
            ViewBag.AllowedBrowser = Reusable.BrowserCheck(Request.Browser.Browser); // Checking Browser

            //API Call		
            ArrayList _Array = new ArrayList();
            _Array.Add(Convert.ToString(PageNum == null ? 1 : PageNum));
            _Array.Add(ClassifiedName);
            _Array.Add(_SessionUserDetails.UserId.ToString());

            string response = ApiHelper.PostData_Json("api/UserPresentation/GridClassifieds?Values=", _Array);
            Result<List<SE_Business>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Business>>>(response);
            List_SE_Business _lst = new List_SE_Business();
            _lst.BusinessList = _Result.Data;

            if (_Result.Data.Count > 0)
                ViewBag.Classified = _Result.Data[0].Classifieds.ToString();

            return View(_lst);
        }
        public ActionResult ViewBusinessRecord(int Id)
        {
            ViewBag.AllowedBrowser = Reusable.BrowserCheck(Request.Browser.Browser); // Checking Browser

            //API Call		
            ArrayList _Array = new ArrayList();
            _Array.Add(_SessionUserDetails.UserId.ToString());
            _Array.Add(Id.ToString());

            string response = ApiHelper.PostData_Json("api/UserPresentation/ViewBusinessRecord?Values=", _Array);
            Result<BusinessComments> _Result = JsonConvert.DeserializeObject<Result<BusinessComments>>(response);
            BusinessComments _Data = _Result.Data;
            _Data.RawHTML = Reusable.RawHTMLComments(_Result.Data.CommentsList);
            return View(_Data);
        }
        #endregion

        #region Community
        public ActionResult Community(int? PageNum)
        {
            ViewBag.AllowedBrowser = Reusable.BrowserCheck(Request.Browser.Browser); // Checking Browser

            ////API Call		
            //ArrayList _Array = new ArrayList();
            //_Array.Add(Convert.ToString(PageNum == null ? 1 : PageNum));
            //_Array.Add(_SessionUserDetails.UserId.ToString());

            //string response = ApiHelper.PostData_Json("api/UserPresentation/GridCommunity?Values=", _Array);
            //Result<List<SE_Business>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Business>>>(response);
            //List_SE_Business _lst = new List_SE_Business();
            //_lst.BusinessList = _Result.Data;

            //if (_Result.Data.Count > 0)
            //    ViewBag.Classified = _Result.Data[0].Classifieds.ToString();

            //return View(_lst);

            return View();
        }

        public ActionResult SearchJoinCommunity()
        {
            try
            {
                return View("../PartialViews/AddJoinCommunity");
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost]
        public JsonResult AutoCompleteCommunities(string prefix)
        {
            List<SelectListItem> CommunityList = Reusable.ComunityList(); // All Communities

            List<string> SList = new List<string>();
            foreach (var Val in CommunityList)
                SList.Add(Val.Text.ToString());

            SList = SList.FindAll(s => s.IndexOf(prefix, StringComparison.OrdinalIgnoreCase) >= 0);
            return Json(SList);
        }
        #endregion


        #region Comments
        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertComments(string Comments, string PageColumnId, string PageId)
        {
            try
            {
                //Server-Side Validations
                if (Comments == null || Sanitizer.GetSafeHtmlFragment(Comments) == "" || Sanitizer.GetSafeHtmlFragment(Comments).Length > 500 || Sanitizer.GetSafeHtmlFragment(Comments).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(Comments);
                _Array.Add(PageColumnId.ToString());
                _Array.Add(PageId.ToString());
                _Array.Add(_SessionUserDetails.UserId.ToString());

                string response = ApiHelper.PostData_Json("api/UserPresentation/InsertComments?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<bool>(false, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertReplyComments(string Comments, string PageColumnId, string PageId, string ParentCommentId)
        {
            try
            {
                //Server-Side Validations
                if (Comments == null || Sanitizer.GetSafeHtmlFragment(Comments) == "" || Sanitizer.GetSafeHtmlFragment(Comments).Length > 500 || Sanitizer.GetSafeHtmlFragment(Comments).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(Comments);
                _Array.Add(PageColumnId.ToString());
                _Array.Add(PageId.ToString());
                _Array.Add(_SessionUserDetails.UserId.ToString());
                _Array.Add(ParentCommentId);

                string response = ApiHelper.PostData_Json("api/UserPresentation/InsertReplyComments?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<bool>(false, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Unused - Cross Check
        //public List<SE_Comments> InnerResult(List<SE_Comments> _Result, int CommentId)
        //{
        //    List<SE_Comments> _InnerResult = new List<SE_Comments>();
        //    foreach (SE_Comments Val in _Result)
        //    {
        //        SE_Comments SingleRec = new SE_Comments();
        //        if (CommentId == Val.ParentCommentId)
        //        {
        //            SingleRec.CommentId = Val.CommentId;
        //            SingleRec.ParentCommentId = Val.ParentCommentId;
        //            SingleRec.Comments = Val.Comments;
        //            SingleRec.ReplyUserId = Val.ReplyUserId;
        //            SingleRec.PageId = Val.PageId;
        //            SingleRec.PageColumnId = Val.PageColumnId;
        //            SingleRec.ReplyFirstName = RSAPattern.Decrypt(Val.ReplyFirstName);
        //            SingleRec.ReplyLastName = RSAPattern.Decrypt(Val.ReplyLastName);
        //            SingleRec.ReplyPhoto = Val.ReplyPhoto.ToString();
        //            SingleRec.CommentedDate = Val.CommentedDate;
        //            SingleRec.FullStringDate = Val.CommentedDate.ToString("ddd, dd MMM yyyy") + ", " + Val.CommentedDate.ToString("hh:mm tt");
        //            SingleRec.HavingParentCommentId = Val.HavingParentCommentId;
        //            SingleRec.InnerComments = InnerResult(Val.InnerComments, SingleRec.CommentId);

        //            _InnerResult.Add(SingleRec);
        //        }
        //    }
        //    return _InnerResult;
        //}
        #endregion
    }
}