﻿using Application.Filters;
using Application.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.Controllers
{
    public class ErrorController : Controller
    {
        [MVCSessionFilter]
        public ActionResult Unauthorized()
        {
            try
            {
                if (SessionHandler.Menus == null || SessionHandler.Menus == "")
                    Reusable.BindMenus();
                ViewBag.Menus = SessionHandler.Menus;
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        [MVCSessionFilter]
        public ActionResult InternalServerError()
        {
            try
            {
                if (SessionHandler.Menus == null || SessionHandler.Menus == "")
                    Reusable.BindMenus();
                ViewBag.Menus = SessionHandler.Menus;
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        [MVCSessionFilter]
        public ActionResult MultiLogin()
        {
            try
            {
                if (SessionHandler.Menus == null || SessionHandler.Menus == "")
                    Reusable.BindMenus();
                ViewBag.Menus = SessionHandler.Menus;
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        public ActionResult SessionExpired()
        {
            try
            {
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }
    }
}