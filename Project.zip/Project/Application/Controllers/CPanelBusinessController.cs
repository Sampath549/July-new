﻿using Application.App_Start;
using Application.Filters;
using Application.Helper;
using Application.Models.SharedEntities;
using Microsoft.Security.Application;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace Application.Controllers
{
    [MVCSessionFilter, MultiLoginFilter, MVCBusinessAuthorization]
    public class CPanelBusinessController : Controller
    {
        #region Global Variables & Default Constructor 
        public SE_Users _SessionUserDetails;
        public CPanelBusinessController()
        {
            ViewBag.DisplayModalPopup = Reusable.CheckIsFirstTimeLogin();   // Model PopUp   
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
        }
        #endregion

        #region Dashboard
        public ActionResult Dashboard()
        {
            try
            {
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }
        #endregion

        #region Classifieds
        public ActionResult Records(int? PageNum)
        {
            try
            {
                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(Convert.ToString(PageNum == null ? 1 : PageNum));
                _Array.Add(_SessionUserDetails.UserId.ToString());

                string response = ApiHelper.PostData_Json("api/CPanelBusiness/GridBussinessPosts?Values=", _Array);
                Result<List<SE_Business>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Business>>>(response);
                List_SE_Business _lst = new List_SE_Business();
                _lst.BusinessList = _Result.Data;

                return View(_lst);
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }
        public ActionResult AddRecords()
        {
            try
            {
                ViewBag.Classifieds = Reusable.ClassifiedsList();
                ViewBag.States = Reusable.StatesList();
                ViewBag.Countries = Reusable.CountriesList();

                return View("../PartialViews/AddBusinessRecords");
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertRecords(SE_Business _Records)
        {
            try
            {
                //Server-Side Validations
                if (_Records.ClassifiedId == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Records.ClassifiedId)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Records.CountryId)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);
                if (_Records.Title == null || Sanitizer.GetSafeHtmlFragment(_Records.Title) == "" || Sanitizer.GetSafeHtmlFragment(_Records.Title).Length > 50 || Sanitizer.GetSafeHtmlFragment(_Records.Title).Length < 5)
                    return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);
                if (_Records.Address == null || Sanitizer.GetSafeHtmlFragment(_Records.Address) == "" || Sanitizer.GetSafeHtmlFragment(_Records.Address).Length > 50 || Sanitizer.GetSafeHtmlFragment(_Records.Address).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);
                if (_Records.City == null || Sanitizer.GetSafeHtmlFragment(_Records.City) == "" || Sanitizer.GetSafeHtmlFragment(_Records.City).Length > 30 || Sanitizer.GetSafeHtmlFragment(_Records.City).Length < 2)
                    return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);
                if (_Records.StateId == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Records.StateId)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Records.StateId)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);
                if (_Records.CountryId == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Records.CountryId)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Records.CountryId)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);
                if (_Records.ZipCode == null || Sanitizer.GetSafeHtmlFragment(_Records.ZipCode) == "" || Sanitizer.GetSafeHtmlFragment(_Records.ZipCode).Length > 5 || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Records.ZipCode)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);
                if (_Records.Description == null || Sanitizer.GetSafeHtmlFragment(_Records.Description) == "" || Sanitizer.GetSafeHtmlFragment(_Records.Description).Length > 300 || Sanitizer.GetSafeHtmlFragment(_Records.Description).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);
                if (_Records.ImagePath != null)
                {
                    List<string> _ext = Reusable.ProfilePicExtentions();
                    if (!_ext.Contains(_Records.ImgType))
                        return Json(new Result(false, 500, "Validation Error", null), JsonRequestBehavior.AllowGet);
                }
                _Records.UserId = _SessionUserDetails.UserId;

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Records);
                string response = ApiHelper.PostData_Json("api/CPanelBusiness/InsertRecords?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<bool>(false, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult ViewRecords(int Id)
        {
            try
            {
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_SessionUserDetails.UserId.ToString());
                _Array.Add(Id.ToString());

                string response = ApiHelper.PostData_Json("api/CPanelBusiness/ViewSingleRecord?Values=", _Array);
                Result<BusinessComments> _Result = JsonConvert.DeserializeObject<Result<BusinessComments>>(response);
                BusinessComments _Data = _Result.Data;
                _Data.RawHTML = Reusable.RawHTMLComments(_Result.Data.CommentsList);
                return View(_Data);
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }
        #endregion

        #region Unused Code
        //public List<SE_Comments> InnerResult(List<SE_Comments> _Result, int CommentId)
        //{
        //    List<SE_Comments> _InnerResult = new List<SE_Comments>();
        //    foreach (SE_Comments Val in _Result)
        //    {
        //        SE_Comments SingleRec = new SE_Comments();
        //        if (CommentId == Val.ParentCommentId)
        //        {
        //            SingleRec.CommentId = Val.CommentId;
        //            SingleRec.ParentCommentId = Val.ParentCommentId;
        //            SingleRec.Comments = Val.Comments;
        //            SingleRec.ReplyUserId = Val.ReplyUserId;
        //            SingleRec.PageId = Val.PageId;
        //            SingleRec.PageColumnId = Val.PageColumnId;
        //            SingleRec.ReplyFirstName = RSAPattern.Decrypt(Val.ReplyFirstName);
        //            SingleRec.ReplyLastName = RSAPattern.Decrypt(Val.ReplyLastName);
        //            SingleRec.ReplyPhoto = Val.ReplyPhoto.ToString();
        //            SingleRec.CommentedDate = Val.CommentedDate;
        //            SingleRec.FullStringDate = Val.CommentedDate.ToString("ddd, dd MMM yyyy") + ", " + Val.CommentedDate.ToString("hh:mm tt");
        //            SingleRec.HavingParentCommentId = Val.HavingParentCommentId;
        //            SingleRec.InnerComments = InnerResult(Val.InnerComments, SingleRec.CommentId);

        //            _InnerResult.Add(SingleRec);
        //        }
        //    }
        //    return _InnerResult;
        //}
        #endregion
    }
}