﻿using Application.Helper;
using Application.Models.DataObjects;
using Application.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Application.Controllers.API
{
    [Authorize(Roles = "BUS"), RoutePrefix("api/CPanelBusiness")]
    public class CPanelBusinessApiController : ApiController
    {
        #region Global Variables
        CPanelBusinessDAL _ObjCPanelBusiness = new CPanelBusinessDAL();
        #endregion

        #region Bussiness
        [HttpPost, Route("GridBussinessPosts")]
        public Result<List<SE_Business>> GridBussinessPosts(ArrayList Array)
        {
            List<string> _lstPage = new List<string>();
            List<SE_Business> _Result = new List<SE_Business>();
            try
            {
                foreach (string val in Array)
                    _lstPage.Add(val.ToString());

                _Result = _ObjCPanelBusiness.GridBussinessPosts(Convert.ToInt32(_lstPage[0]), Convert.ToInt32(_lstPage[1]), null, null);
                return Result.Success(_Result, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("InsertRecords")]
        public Result InsertRecords(ArrayList Array)
        {
            SE_Business _AccPosts = new SE_Business();
            try
            {
                foreach (JObject val in Array)
                    _AccPosts = val.ToObject<SE_Business>();

                int _Result = _ObjCPanelBusiness.InsertRecords(_AccPosts);
                if (_Result == 1)
                    return Result.Success(200, GlobalVariables.Shared.RecSaveSuccessMsg, GlobalVariables.Shared.SuccessMsg);
                else
                    return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("ViewSingleRecord")]
        public Result<BusinessComments> ViewSingleRecord(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            BusinessComments _Result = new BusinessComments();
            try
            {
                foreach (string val in Array)
                    _lst.Add(val.ToString());

                _Result = _ObjCPanelBusiness.ViewSingleRecord(Convert.ToInt32(_lst[0]), Convert.ToInt32(_lst[1]));
                return Result.Success(_Result, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }
        #endregion
    }
}
