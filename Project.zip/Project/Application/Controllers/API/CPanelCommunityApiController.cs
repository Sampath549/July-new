﻿using Application.Helper;
using Application.Models.DataObjects;
using Application.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Application.Controllers.API
{
    [Authorize(Roles = "COMM"), RoutePrefix("api/CPanelCommunity")]
    public class CPanelCommunityApiController : ApiController
    {
        #region Global Variables
        CPanelCommunityDAL _ObjCPanelCommunity = new CPanelCommunityDAL();
        #endregion

        [HttpPost, Route("GridBMembers")]
        public Result<List<SE_BMembers>> GridBMembers(ArrayList Array)
        {
            string _CID = string.Empty;
            List<SE_BMembers> _Result = new List<SE_BMembers>();
            try
            {
                foreach (string val in Array)
                    _CID = val.ToString();

                _Result = _ObjCPanelCommunity.GridBMembers(Convert.ToInt32(_CID));
                return Result.Success(_Result, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("InsertBMembers")]
        public Result InsertBMembers(ArrayList Array)
        {
            SE_BMembers _Users = new SE_BMembers();
            try
            {
                foreach (JObject val in Array)
                    _Users = val.ToObject<SE_BMembers>();

                int _Result = _ObjCPanelCommunity.InsertBMembers(_Users);
                if (_Result == 1)
                    return Result.Success(200, GlobalVariables.Shared.RecSaveSuccessMsg, GlobalVariables.Shared.SuccessMsg);
                else
                    return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("GetEvents")]
        public Result<List<SE_Events>> GetEvents(ArrayList Array)
        {
            List<string> _lstPage = new List<string>();
            List<SE_Events> _Result = new List<SE_Events>();
            try
            {
                foreach (string val in Array)
                    _lstPage.Add(val.ToString());

                _Result = _ObjCPanelCommunity.GetEvents(Convert.ToInt32(_lstPage[0]));
                return Result.Success(_Result, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }
        [HttpPost, Route("SingleEvent")]
        public Result<SE_Events> SingleEvent(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            SE_Events _Result = new SE_Events();
            try
            {
                foreach (string val in Array)
                    _lst.Add(val.ToString());

                _Result = _ObjCPanelCommunity.SingleEvent(Convert.ToInt32(_lst[0]), Convert.ToInt32(_lst[1]));
                return Result.Success(_Result, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("InsertEvents")]
        public Result InsertEvents(ArrayList Array)
        {
            SE_Events _Users = new SE_Events();
            try
            {
                foreach (JObject val in Array)
                    _Users = val.ToObject<SE_Events>();

                int _Result = _ObjCPanelCommunity.InsertEvents(_Users);
                if (_Result == 1)
                    return Result.Success(200, GlobalVariables.Shared.RecSaveSuccessMsg, GlobalVariables.Shared.SuccessMsg);
                else
                    return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("GetPolls")]
        public Result<List<SE_Polls>> GetPolls(ArrayList Array)
        {
            List<string> _lstPage = new List<string>();
            List<SE_Polls> _Result = new List<SE_Polls>();
            try
            {
                foreach (string val in Array)
                    _lstPage.Add(val.ToString());

                _Result = _ObjCPanelCommunity.GetPolls(Convert.ToInt32(_lstPage[0]));
                return Result.Success(_Result, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("InsertPolls")]
        public Result InsertPolls(ArrayList Array)
        {
            SE_Polls _Users = new SE_Polls();
            try
            {
                foreach (JObject val in Array)
                    _Users = val.ToObject<SE_Polls>();

                int _Result = _ObjCPanelCommunity.InsertPolls(_Users);
                if (_Result == 1)
                    return Result.Success(200, GlobalVariables.Shared.RecSaveSuccessMsg, GlobalVariables.Shared.SuccessMsg);
                else
                    return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }
    }
}
