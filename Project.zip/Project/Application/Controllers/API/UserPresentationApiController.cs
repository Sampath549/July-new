﻿using Application.Helper;
using Application.Models.DataObjects;
using Application.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Application.Controllers.API
{
    [Authorize(Roles = "USR"), RoutePrefix("api/UserPresentation")]
    public class UserPresentationApiController : ApiController
    {
        #region Global Variables
        CPanelUserDAL _ObjCPanelUser = new CPanelUserDAL();
        CPanelBusinessDAL _ObjCPanelBusiness = new CPanelBusinessDAL();
        SharedDAL _ObjCPanelShared = new SharedDAL();
        #endregion

        [HttpPost, Route("GridAccPosts")]
        public Result<List<SE_Accommodation>> GridAccPosts(ArrayList Array)
        {
            List<string> _lstPage = new List<string>();
            List<SE_Accommodation> _Result = new List<SE_Accommodation>();
            try
            {
                foreach (string val in Array)
                    _lstPage.Add(val.ToString());

                _Result = _ObjCPanelUser.GridAccPosts(Convert.ToInt32(_lstPage[0]), null, Convert.ToInt32(_lstPage[1]));
                return Result.Success(_Result, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("SingleAccPosts")]
        public Result<ViewPost_Comments> SingleAccPosts(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            ViewPost_Comments _Result = new ViewPost_Comments();
            try
            {
                foreach (string val in Array)
                    _lst.Add(val.ToString());

                _Result = _ObjCPanelUser.SingleAccPosts(Convert.ToInt32(_lst[0]), Convert.ToInt32(_lst[1]));
                return Result.Success(_Result, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("GridBuySellPosts")]
        public Result<List<SE_BuySell>> GridBuySellPosts(ArrayList Array)
        {
            List<string> _lstPage = new List<string>();
            List<SE_BuySell> _Result = new List<SE_BuySell>();
            try
            {
                foreach (string val in Array)
                    _lstPage.Add(val.ToString());

                _Result = _ObjCPanelUser.GridBuySellPosts(Convert.ToInt32(_lstPage[0]), null, Convert.ToInt32(_lstPage[1]));
                return Result.Success(_Result, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("SingleBSPosts")]
        public Result<ViewBSPost_Comments> SingleBSPosts(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            ViewBSPost_Comments _Result = new ViewBSPost_Comments();
            try
            {
                foreach (string val in Array)
                    _lst.Add(val.ToString());

                _Result = _ObjCPanelUser.SingleBSPosts(Convert.ToInt32(_lst[0]), Convert.ToInt32(_lst[1]));
                return Result.Success(_Result, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("GridClassifieds")]
        public Result<List<SE_Business>> GridClassifieds(ArrayList Array)
        {
            List<string> _lstPage = new List<string>();
            List<SE_Business> _Result = new List<SE_Business>();
            try
            {
                foreach (string val in Array)
                    _lstPage.Add(val.ToString());

                _Result = _ObjCPanelBusiness.GridBussinessPosts(Convert.ToInt32(_lstPage[0]), null, Convert.ToString(_lstPage[1]), Convert.ToInt32(_lstPage[2]));
                return Result.Success(_Result, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("ViewBusinessRecord")]
        public Result<BusinessComments> ViewBusinessRecord(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            BusinessComments _Result = new BusinessComments();
            try
            {
                foreach (string val in Array)
                    _lst.Add(val.ToString());

                _Result = _ObjCPanelBusiness.ViewSingleRecord(Convert.ToInt32(_lst[0]), Convert.ToInt32(_lst[1]));
                return Result.Success(_Result, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("InsertComments")]
        public Result InsertComments(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (string val in Array)
                    _lst.Add(val.ToString());

                int _Result = _ObjCPanelShared.InsertComments(_lst[0], Convert.ToInt32(_lst[1]), _lst[2], Convert.ToInt32(_lst[3]));

                if (_Result == 1)
                    return Result.Success(200, GlobalVariables.Shared.CommentPostedSuccessMsg, GlobalVariables.Shared.SuccessMsg);
                else
                    return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("InsertReplyComments")]
        public Result InsertReplyComments(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (string val in Array)
                    _lst.Add(val.ToString());

                int _Result = _ObjCPanelShared.InsertReplyComments(_lst[0], Convert.ToInt32(_lst[1]), _lst[2], Convert.ToInt32(_lst[3]), Convert.ToInt32(_lst[4]));

                if (_Result == 1)
                    return Result.Success(200, "Success", "Comment Posted Succesfully");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("CommunityList")]
        public Result<List<SE_RefValues>> CommunityList(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjCPanelShared.CommunityList();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }
    }
}
