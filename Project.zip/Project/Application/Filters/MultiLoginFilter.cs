﻿using Application.Helper;
using Application.Models.SharedEntities;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Application.Filters
{
    public class MultiLoginFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            HttpContext ctx = HttpContext.Current;

            SE_Users Users = SessionHandler.UserDetails as SE_Users;
            if (Users != null)
            {
                string MultiLoginSession = string.Empty;
                if (GlobalVariables.Shared.MultiLoginEnable)
                {
                    //Check-MultiLogin
                    if (System.Web.HttpContext.Current.Session["MultiLogin"] != null)
                        MultiLoginSession = System.Web.HttpContext.Current.Session["MultiLogin"].ToString();
                    else
                        MultiLoginSession = "";

                    //API Call
                    ArrayList _MultiLoginArray = new ArrayList();
                    _MultiLoginArray.Add(RSAPattern.Encrypt(Users.Email));
                    _MultiLoginArray.Add(RSAPattern.Encrypt(MultiLoginSession));
                    _MultiLoginArray.Add(RSAPattern.Encrypt(GlobalVariables.Shared.MultiLoginCheck));

                    string res = ApiHelper.PostData_Json_NToken("api/CPanel/MultiLogin?Values=", _MultiLoginArray);
                    Result<int> _ResultMultiLogin = JsonConvert.DeserializeObject<Result<int>>(res);

                    if (Convert.ToBoolean(_ResultMultiLogin.Data))
                    {
                        var values = new RouteValueDictionary(new { action = GlobalVariables.Shared.MultiLogin, controller = "Error" });
                        filterContext.Result = new RedirectToRouteResult(values);
                        return;
                    }
                }
            }
            else
            {
                var values = new RouteValueDictionary(new { action = GlobalVariables.Shared.SessionExpired, controller = "Error" });
                filterContext.Result = new RedirectToRouteResult(values);
                return;
            }
            base.OnActionExecuting(filterContext);
        }
    }
}