﻿using Application.Helper;
using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace Application.Models.DataObjects
{
    public partial class CPanelDAL : DataAccessComponent
    {
        SharedDAL _ObjShared = new SharedDAL();
        public int InsertRegistration(SE_Users _Data)
        {
            bool EmailMobileExists = CheckEmailMobile(_Data.Email, _Data.Mobile);
            if (!EmailMobileExists)
            {
                SqlConnection con = new SqlConnection(DBConnect);
                con.Open();
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "USP_Insert_Registration";
                    cmd.Parameters.Add("@PersonalKey", SqlDbType.VarChar).Value = _Data.PersonalKey;
                    cmd.Parameters.Add("@FirstName", SqlDbType.VarChar).Value = _Data.FirstName;
                    cmd.Parameters.Add("@LastName", SqlDbType.VarChar).Value = _Data.LastName;
                    cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = _Data.Email;
                    cmd.Parameters.Add("@Mobile", SqlDbType.VarChar).Value = _Data.Mobile;
                    cmd.Parameters.Add("@RoleCode", SqlDbType.VarChar).Value = _Data.RoleCode;
                    cmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = _Data.Password;
                    cmd.Parameters.Add("@SaltKey", SqlDbType.VarChar).Value = _Data.SaltKey;

                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();

                    if (GlobalVariables.Shared.SavePasswords)
                        Reusable.SaveRegistration(_Data.PersonalKey, _Data.Email, _Data.FirstName, _Data.LastName, _Data.Mobile);
                    return 1;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
            else
                return 101; // Email Or Mobile already Exists
        }
        private bool CheckEmailMobile(string Email, string Mobile)
        {
            DataSet _Result = new DataSet();
            using (SqlConnection con = new SqlConnection(DBConnect))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
                    da.SelectCommand = new SqlCommand("SELECT Count(*) [Count] FROM [tbl_Users] WHERE EmailId = @Email OR Mobile = @Mobile", con);
                    da.SelectCommand.CommandType = CommandType.Text;
                    da.SelectCommand.Parameters.AddWithValue("@Email", Email);
                    da.SelectCommand.Parameters.AddWithValue("@Mobile", Mobile);

                    da.Fill(_Result);
                }
            }

            if (Convert.ToInt32(_Result.Tables[0].Rows[0]["Count"]) == 0)
                return false;
            else
                return true;
        }
        public int InsertResetPwdLog(string GuidValue, string _Email)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            try
            {
                int UserId = _ObjShared.GetUserIdByEmail(_Email);
                if (UserId > 0)
                {
                    DateTime CurrentDate = DateTime.Now;
                    DataSet ds = new DataSet();
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT MAX(EntryDate) AS MaxTime FROM [tbl_ResetPwdLog] WHERE UserId = @UserId", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@UserId", UserId);
                        da.Fill(ds);
                    }

                    if (ds.Tables[0].Rows[0]["MaxTime"] != DBNull.Value)
                    {
                        int TotalTime = Convert.ToInt32(CurrentDate.Subtract(Convert.ToDateTime(ds.Tables[0].Rows[0]["MaxTime"])).TotalMinutes);
                        int ExpiryTime = GlobalVariables.Shared.ForgotPwdClickAgain;
                        if (TotalTime < ExpiryTime)
                            return 201;
                    }

                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "USP_Insert_ResetPwdLog";
                    cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
                    cmd.Parameters.Add("@GuidVal", SqlDbType.VarChar).Value = GuidValue;

                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    return 1;
                }
                else
                    return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public string GetExpiryDate_IsReset(string GuidValue)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT EntryDate, IsReset FROM [tbl_ResetPwdLog] WHERE GuidVal = @GuidValue", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@GuidValue", GuidValue);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    return Convert.ToString(_Result.Tables[0].Rows[0]["EntryDate"]) + "^" + Convert.ToString(_Result.Tables[0].Rows[0]["IsReset"]);
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int ResetPassword(string EmailCheck, string Password, string SaltKey, string GuidVal)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                int UserId = _ObjShared.GetUserIdByEmail(EmailCheck);
                if (UserId > 0)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "USP_Update_ResetPwd";
                    cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
                    cmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = Password;
                    cmd.Parameters.Add("@SaltKey", SqlDbType.VarChar).Value = SaltKey;
                    cmd.Parameters.Add("@GuidVal", SqlDbType.VarChar).Value = GuidVal;
                    cmd.Parameters.Add("@ExpiryTime", SqlDbType.Int).Value = GlobalVariables.Shared.EmailLinkExpiry;

                    SqlParameter OutputParam = new SqlParameter("@OutputResult", SqlDbType.Int)
                    {
                        Direction = ParameterDirection.Output
                    };
                    cmd.Parameters.Add(OutputParam);
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();

                    Status = int.Parse(OutputParam.Value.ToString());
                    return Status;
                }
                else
                    return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public bool InsertAuditLogin(int UserId, string Email, string IPAddr, string EntryType, string EntryFrom, string Browser, string Resolution, string Location, string Latitude, string Longitude, bool IsSuccess)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_Audit";
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
                cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = Email;
                cmd.Parameters.Add("@IPAddr", SqlDbType.VarChar).Value = IPAddr;
                cmd.Parameters.Add("@EntryType", SqlDbType.VarChar).Value = EntryType;
                cmd.Parameters.Add("@EntryFrom", SqlDbType.VarChar).Value = EntryFrom;
                cmd.Parameters.Add("@Browser", SqlDbType.VarChar).Value = Browser;
                cmd.Parameters.Add("@Resolution", SqlDbType.VarChar).Value = Resolution;
                cmd.Parameters.Add("@Location", SqlDbType.VarChar).Value = Location;
                cmd.Parameters.Add("@Latitude", SqlDbType.VarChar).Value = Latitude;
                cmd.Parameters.Add("@Longitude", SqlDbType.VarChar).Value = Longitude;
                cmd.Parameters.Add("@IsSuccess", SqlDbType.Bit).Value = IsSuccess;

                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public void UpdateAttemptsFailed(int UserId)
        {
            DataSet _Result = new DataSet();
            using (SqlConnection con = new SqlConnection(DBConnect))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
                    da.SelectCommand = new SqlCommand("USP_Update_FailedLoginAttempts", con);
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    da.SelectCommand.Parameters.AddWithValue("@UserId", UserId);
                    da.Fill(_Result);
                }
            }
        }
        public SE_Users AuthenticatedUser(string Email, string Password)
        {
            SE_Users _Result = new SE_Users();
            DataTable dtUserDetails = new DataTable();
            using (SqlConnection con = new SqlConnection(DBConnect))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
                    da.SelectCommand = new SqlCommand("USP_Get_AuthenticatedUser", con);
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    da.SelectCommand.Parameters.AddWithValue("@EmailId", Email);
                    da.SelectCommand.Parameters.AddWithValue("@Password", Password);

                    da.Fill(dtUserDetails);

                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["UserId"].ToString()))
                    {
                        _Result.Status = Convert.ToInt32(dtUserDetails.Rows[0]["Status"]);
                        _Result.UserId = Convert.ToInt32(dtUserDetails.Rows[0]["UserId"]);
                        _Result.FirstName = Convert.ToString(dtUserDetails.Rows[0]["FirstName"]);
                        _Result.LastName = Convert.ToString(dtUserDetails.Rows[0]["LastName"]);
                        _Result.FullName = Convert.ToString(dtUserDetails.Rows[0]["FullName"]);
                        _Result.Email = Convert.ToString(dtUserDetails.Rows[0]["Email"]);
                        _Result.Mobile = Convert.ToString(dtUserDetails.Rows[0]["Mobile"]);
                        _Result.RoleId = Convert.ToInt32(dtUserDetails.Rows[0]["RoleId"]);
                        _Result.RoleCode = Convert.ToString(dtUserDetails.Rows[0]["RoleCode"]);
                        _Result.IsFirstTimeLogin = Convert.ToBoolean(dtUserDetails.Rows[0]["IsFirstTimeLogin"]);
                        if (dtUserDetails.Rows[0]["Photo"] != DBNull.Value)
                            _Result.ProfilePic = Convert.ToString(dtUserDetails.Rows[0]["Photo"]);
                        if (dtUserDetails.Rows[0]["DisableAccountTime"] != DBNull.Value)
                            _Result.DisableAccountTime = Convert.ToDateTime(dtUserDetails.Rows[0]["DisableAccountTime"]);
                        if (dtUserDetails.Rows[0]["TimeDiff"] != DBNull.Value)
                            _Result.TimeDiff = Convert.ToInt32(dtUserDetails.Rows[0]["TimeDiff"]);
                    }
                    if (dtUserDetails.Rows[0]["FailedLoginAttempts"] != DBNull.Value)
                        _Result.FailedLoginAttempts = Convert.ToInt32(dtUserDetails.Rows[0]["FailedLoginAttempts"]);
                }
            }
            return _Result;
        }
        public string GetMenus(string RoleCode)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_MenuListByRole", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@RoleCode", RoleCode);

                        da.Fill(_Result);
                    }
                }
                return JsonMenusList(_Result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string JsonMenusList(DataSet _Result)
        {
            try
            {
                var _Menus = new StringBuilder();
                if (_Result.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < _Result.Tables[0].Rows.Count; i++)
                    {
                        if (!Convert.ToBoolean(_Result.Tables[0].Rows[i]["HavingChild"]))
                            _Menus.Append("<li id='menu" + i + "'><a href='/" + _Result.Tables[0].Rows[i]["Controller"].ToString() + "/" + _Result.Tables[0].Rows[i]["Action"].ToString() + "'><i class='" + _Result.Tables[0].Rows[i]["Icon"].ToString() + "'></i> " + _Result.Tables[0].Rows[i]["Header"].ToString() + "</a></li>");
                        else
                        {
                            _Menus.Append("<li id='menu" + i + "'>");
                            _Menus.Append("<a id='submenu" + i + "' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'><i class='" + _Result.Tables[0].Rows[i]["Icon"].ToString() + "'></i> " + _Result.Tables[0].Rows[i]["Header"].ToString() + "</a>");
                            _Menus.Append("<ul class='dropdown-menu' aria-labelledby='submenu" + i + "'>");
                            for (int j = 0; j < _Result.Tables[1].Rows.Count; j++)
                            {
                                if (Convert.ToInt32(_Result.Tables[0].Rows[i]["ParentId"]) == Convert.ToInt32(_Result.Tables[1].Rows[j]["ParentId"]))
                                    _Menus.Append("<li><a href='/" + _Result.Tables[1].Rows[j]["Controller"].ToString() + "/" + _Result.Tables[1].Rows[j]["Action"].ToString() + "'>" + _Result.Tables[1].Rows[j]["Header"].ToString() + "</a></li>");
                            }
                            _Menus.Append("</ul>");
                            _Menus.Append("</li>");
                        }
                    }
                }
                return _Menus.ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int InsertMultiLogin(string UserEmail, string SessionToken, string Flag)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Check_MultiLogin";
                cmd.Parameters.Add("@UserEmail", SqlDbType.VarChar).Value = UserEmail;
                cmd.Parameters.Add("@SessionToken", SqlDbType.VarChar).Value = SessionToken;
                cmd.Parameters.Add("@Flag", SqlDbType.VarChar).Value = Flag;

                SqlParameter OutPutParam = new SqlParameter("@IsMultiLogin", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(OutPutParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                return int.Parse(OutPutParam.Value.ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int UpdateMultiLogin(string UserEmail)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_MultiLogin";
                cmd.Parameters.Add("@UserEmail", SqlDbType.VarChar).Value = UserEmail;

                SqlParameter OutPutParam = new SqlParameter("@IsSuccess", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(OutPutParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                return int.Parse(OutPutParam.Value.ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int OneTimePassword(int UserId, string OldPwd, string OldKey, string NewPwd, string NewKey)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Update_OneTimeLogin";
                cmd.Parameters.Add("@UserId", SqlDbType.VarChar).Value = UserId;
                cmd.Parameters.Add("@OldPwd", SqlDbType.VarChar).Value = OldPwd;
                cmd.Parameters.Add("@OldKey", SqlDbType.VarChar).Value = OldKey;
                cmd.Parameters.Add("@NewPwd", SqlDbType.VarChar).Value = NewPwd;
                cmd.Parameters.Add("@NewKey", SqlDbType.VarChar).Value = NewKey;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch
            {
                return Status;
            }
            finally
            {
                con.Close();
            }
        }
        public SE_MyProfile MyProfileDetails(string Email)
        {
            SE_MyProfile _Result = new SE_MyProfile();
            DataTable dtUserDetails = new DataTable();
            using (SqlConnection con = new SqlConnection(DBConnect))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
                    da.SelectCommand = new SqlCommand("USP_Get_UserMappingDetails", con);
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    da.SelectCommand.Parameters.AddWithValue("@Email", Email);

                    da.Fill(dtUserDetails);

                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["UserId"].ToString()))
                        _Result.UserId = Convert.ToInt32(dtUserDetails.Rows[0]["UserId"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["Gender"].ToString()))
                        _Result.Gender = Convert.ToString(dtUserDetails.Rows[0]["Gender"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["Photo"].ToString()))
                        _Result.ProfilePic = Convert.ToString(dtUserDetails.Rows[0]["Photo"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["ImgType"].ToString()))
                        _Result.ImgType = Convert.ToString(dtUserDetails.Rows[0]["ImgType"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["IsPermanentAddress"].ToString()))
                        _Result.isCurrentPermanent = Convert.ToBoolean(dtUserDetails.Rows[0]["IsPermanentAddress"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["PAddress"].ToString()))
                        _Result.PAddress = Convert.ToString(dtUserDetails.Rows[0]["PAddress"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["PCity"].ToString()))
                        _Result.PCity = Convert.ToString(dtUserDetails.Rows[0]["PCity"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["PStateId"].ToString()))
                        _Result.PStateId = Convert.ToString(dtUserDetails.Rows[0]["PStateId"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["PCountryId"].ToString()))
                        _Result.PCountryId = Convert.ToString(dtUserDetails.Rows[0]["PCountryId"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["PZipCode"].ToString()))
                        _Result.PZipCode = Convert.ToString(dtUserDetails.Rows[0]["PZipCode"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["CAddress"].ToString()))
                        _Result.CAddress = Convert.ToString(dtUserDetails.Rows[0]["CAddress"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["CCity"].ToString()))
                        _Result.CCity = Convert.ToString(dtUserDetails.Rows[0]["CCity"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["CStateId"].ToString()))
                        _Result.CStateId = Convert.ToString(dtUserDetails.Rows[0]["CStateId"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["CCountryId"].ToString()))
                        _Result.CCountryId = Convert.ToString(dtUserDetails.Rows[0]["CCountryId"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["CZipCode"].ToString()))
                        _Result.CZipCode = Convert.ToString(dtUserDetails.Rows[0]["CZipCode"]);
                }
            }
            return _Result;
        }
        public int InsertUpdateMyProfile(SE_MyProfile _Records)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_MyProfile";

                cmd.Parameters.Add("@ActualEmail", SqlDbType.VarChar).Value = _Records.Email;
                cmd.Parameters.Add("@FirstName", SqlDbType.VarChar).Value = _Records.FirstName;
                cmd.Parameters.Add("@LastName", SqlDbType.VarChar).Value = _Records.LastName;
                cmd.Parameters.Add("@Gender", SqlDbType.Char).Value = _Records.Gender;
                cmd.Parameters.Add("@PAddress", SqlDbType.VarChar).Value = _Records.PAddress;
                cmd.Parameters.Add("@PCity", SqlDbType.VarChar).Value = _Records.PCity;
                cmd.Parameters.Add("@PStateId", SqlDbType.Int).Value = _Records.PStateId;
                cmd.Parameters.Add("@PCountryId", SqlDbType.Int).Value = _Records.PCountryId;
                cmd.Parameters.Add("@PZipCode", SqlDbType.BigInt).Value = _Records.PZipCode;
                cmd.Parameters.Add("@isCurrentPermanent", SqlDbType.Bit).Value = _Records.isCurrentPermanent;
                cmd.Parameters.Add("@CAddress", SqlDbType.VarChar).Value = _Records.CAddress;
                cmd.Parameters.Add("@CCity", SqlDbType.VarChar).Value = _Records.CCity;
                cmd.Parameters.Add("@CStateId", SqlDbType.Int).Value = _Records.CStateId;
                cmd.Parameters.Add("@CCountryId", SqlDbType.Int).Value = _Records.CCountryId;
                cmd.Parameters.Add("@CZipCode", SqlDbType.BigInt).Value = _Records.CZipCode;
                cmd.Parameters.Add("@ProfilePic", SqlDbType.VarChar).Value = _Records.ProfilePic;
                cmd.Parameters.Add("@ImgType", SqlDbType.VarChar).Value = _Records.ImgType;

                SqlParameter outputIdParam = new SqlParameter("@OutputResult", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_RefValues> GetCountries()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT * FROM [Ref_Countries]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["CountryId"]), Code = dr["Code"].ToString(), Description = dr["Description"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_RefValues> GetStates()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT * FROM [Ref_States]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["StateId"]), Code = dr["Code"].ToString(), Description = dr["Description"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_RefValues> GetAllUsers()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT UserId, FirstName, LastName FROM [EuroDB].[tbl_Users] WHERE RoleId = 4", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["UserId"]), Description = AES_Algorithm.DecryptString(dr["FirstName"].ToString()) + " " + AES_Algorithm.DecryptString(dr["LastName"].ToString()) });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_RefValues> GetClassifieds()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT * FROM [EuroDB].[Ref_Classifieds]  ORDER BY [Description]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["ClassifiedId"]), Code = dr["Code"].ToString(), Description = dr["Description"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_RefValues> RolesList()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT RoleId, [Description] FROM [Ref_Roles]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["RoleId"]), Description = dr["Description"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}