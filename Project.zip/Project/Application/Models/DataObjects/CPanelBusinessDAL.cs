﻿using Application.Helper;
using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Application.Models.DataObjects
{
    public partial class CPanelBusinessDAL : DataAccessComponent
    {
        SharedDAL _ObjShared = new SharedDAL();
        public List<SE_Business> GridBussinessPosts(int _PNum, int? UID, string ClassifiedName, int? UserPID)
        {
            try
            {
                List<SE_Business> _Rec = new List<SE_Business>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_GridBusinessPosts", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@PNum", _PNum);
                        da.SelectCommand.Parameters.AddWithValue("@PSize", GlobalVariables.Shared.ContentPageSize);
                        da.SelectCommand.Parameters.AddWithValue("@UID", UID);
                        da.SelectCommand.Parameters.AddWithValue("@ClassifiedName", ClassifiedName);
                        da.SelectCommand.Parameters.AddWithValue("@UserPID", UserPID);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Business
                        {
                            BusinessId = Convert.ToInt32(dr["BusinessId"]),
                            Classifieds = dr["Classifieds"].ToString(),
                            UserId = Convert.ToInt32(dr["UserId"]),
                            Title = dr["Title"].ToString(),
                            Address = dr["Address"].ToString(),
                            City = dr["City"].ToString(),
                            StateDesc = dr["StateDesc"].ToString(),
                            CountryDesc = dr["CountryDesc"].ToString(),
                            Description = dr["Description"].ToString(),
                            CreatedDate = Convert.ToDateTime(dr["CreatedDate"]),
                            DateLongString = dr["DateLongString"].ToString(),
                            TotalComments = Convert.ToInt32(dr["TotalComments"]),
                            TotalRecords = Convert.ToInt32(dr["TotalRecords"]),
                            ImagePath = Convert.ToString(dr["ImagePath"])
                        });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int InsertRecords(SE_Business _Rec)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_BusinessRecords";
                cmd.Parameters.Add("@ClassifiedId", SqlDbType.Int).Value = Convert.ToInt32(_Rec.ClassifiedId);
                cmd.Parameters.Add("@UserId", SqlDbType.VarChar).Value = _Rec.UserId;
                cmd.Parameters.Add("@Title", SqlDbType.VarChar).Value = _Rec.Title;
                cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = _Rec.Address;
                cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = _Rec.City;
                cmd.Parameters.Add("@StateId", SqlDbType.Int).Value = _Rec.StateId;
                cmd.Parameters.Add("@CountryId", SqlDbType.Int).Value = _Rec.CountryId;
                cmd.Parameters.Add("@ZipCode", SqlDbType.Int).Value = _Rec.ZipCode;
                cmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = _Rec.Description;
                cmd.Parameters.Add("@ImagePath", SqlDbType.VarChar).Value = _Rec.ImagePath;
                cmd.Parameters.Add("@ImgType", SqlDbType.VarChar).Value = _Rec.ImgType;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public BusinessComments ViewSingleRecord(int UID, int PageColumnId)
        {
            try
            {
                BusinessComments _FullRecord = new BusinessComments();
                List<SE_Business> _PageList = new List<SE_Business>();
                List<SE_Comments> _CommentsList = new List<SE_Comments>();
                DataSet _PageResult = new DataSet();
                DataSet _CommentsResult = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_BusinessById", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@PageColumnId", PageColumnId);
                        da.Fill(_PageResult);
                    }

                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_DisplayComments", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@UID", UID);
                        da.SelectCommand.Parameters.AddWithValue("@PageId", 3);
                        da.SelectCommand.Parameters.AddWithValue("@PageColumnId", PageColumnId);
                        da.Fill(_CommentsResult);
                    }
                    con.Close();
                }

                if (_PageResult.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _PageResult.Tables[0].Rows)
                    {
                        _PageList.Add(new SE_Business
                        {
                            BusinessId = Convert.ToInt32(dr["BusinessId"]),
                            ClassifiedId = dr["ClassifiedId"].ToString(),
                            Classifieds = dr["Classifieds"].ToString(),
                            UserId = Convert.ToInt32(dr["UserId"]),
                            FirstName = AES_Algorithm.DecryptString(dr["FirstName"].ToString()),
                            LastName = AES_Algorithm.DecryptString(dr["LastName"].ToString()),
                            FullName = AES_Algorithm.DecryptString(dr["FirstName"].ToString()) + " " + AES_Algorithm.DecryptString(dr["LastName"].ToString()),
                            Title = dr["Title"].ToString(),
                            Address = dr["Address"].ToString(),
                            City = dr["City"].ToString(),
                            StateDesc = dr["StateDesc"].ToString(),
                            CountryDesc = dr["CountryDesc"].ToString(),
                            ZipCode = dr["ZipCode"].ToString(),
                            Description = dr["Description"].ToString(),
                            CreatedDate = Convert.ToDateTime(dr["CreatedDate"]),
                            DateLongString = dr["DateLongString"].ToString(),
                            ImagePath = Convert.ToString(dr["ImagePath"])
                        });
                    }

                _FullRecord.Business = _PageList[0];
                _FullRecord.CommentsList = _ObjShared.ResultSetData(_CommentsResult);
                int _CommentsCount = 0;

                foreach (var C in _FullRecord.CommentsList)
                {
                    _CommentsCount += 1;
                    if (C.InnerComments.Count > 0)
                        _CommentsCount = _ObjShared._InnerComments(C.InnerComments, _CommentsCount);
                }
                _FullRecord.TotalComments = _CommentsCount;
                return _FullRecord;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
