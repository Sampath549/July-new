﻿using Application.Helper;
using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Application.Models.DataObjects
{
    public partial class SharedDAL : DataAccessComponent
    {
        public string GetSaltKeyByEmail(string _Email)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT SaltKey FROM [EuroDB].[tbl_Users] WHERE EmailId = @Email", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@Email", _Email);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    return Convert.ToString(_Result.Tables[0].Rows[0]["SaltKey"]);
                else
                    return "";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string GetSaltKeyById(string _Id)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT SaltKey FROM [EuroDB].[tbl_Users] WHERE UserId = @ID", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@ID", _Id);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    return Convert.ToString(_Result.Tables[0].Rows[0]["SaltKey"]);
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int GetUserIdByEmail(string _Email)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT UserId FROM [EuroDB].[tbl_Users] WHERE EmailId = @Email", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@Email", _Email);
                        da.Fill(_Result);
                    }
                }
                if (_Result.Tables[0].Rows.Count > 0)
                    return Convert.ToInt32(_Result.Tables[0].Rows[0]["UserId"]);
                else
                    return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string GetFullNameByEmail(string _Email)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT FirstName, LastName FROM [EuroDB].[tbl_Users] WHERE EmailId = @Email", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@Email", _Email);
                        da.Fill(_Result);
                    }
                }
                if (_Result.Tables[0].Rows.Count > 0)
                    return Convert.ToString(_Result.Tables[0].Rows[0]["FirstName"]) + "^" + Convert.ToString(_Result.Tables[0].Rows[0]["LastName"]);
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int InsertComments(string Comments, int PageColumnId, string PageIdVal, int UserId)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_Comments";
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
                cmd.Parameters.Add("@PageIdVal", SqlDbType.VarChar).Value = PageIdVal;
                cmd.Parameters.Add("@PageColumnId", SqlDbType.Int).Value = PageColumnId;
                cmd.Parameters.Add("@Comments", SqlDbType.VarChar).Value = Comments;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int InsertReplyComments(string Comments, int PageColumnId, string PageIdVal, int UserId, int ParentCommentId)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_ReplyComments";
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
                cmd.Parameters.Add("@PageIdVal", SqlDbType.VarChar).Value = PageIdVal;
                cmd.Parameters.Add("@PageColumnId", SqlDbType.Int).Value = PageColumnId;
                cmd.Parameters.Add("@Comments", SqlDbType.VarChar).Value = Comments;
                cmd.Parameters.Add("@ParentCommentId", SqlDbType.Int).Value = ParentCommentId;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int _InnerComments(List<SE_Comments> Rec, int _CommentsCount)
        {
            foreach (var C in Rec)
            {
                _CommentsCount += 1;
                if (C.InnerComments.Count > 0)
                    _CommentsCount = _InnerComments(C.InnerComments, _CommentsCount);
            }
            return _CommentsCount;
        }
        public List<SE_Comments> ResultSetData(DataSet _Result)
        {
            List<SE_Comments> _List = new List<SE_Comments>();

            if (_Result.Tables.Count > 0)
            {
                foreach (DataRow dr in _Result.Tables[0].Rows)
                {
                    SE_Comments _Rec = new SE_Comments();
                    _Rec.CommentId = Convert.ToInt32(dr["CommentId"]);
                    _Rec.ParentCommentId = Convert.ToInt32(dr["ParentCommentId"]);
                    _Rec.Comments = dr["Comments"].ToString();
                    _Rec.ReplyUserId = Convert.ToInt32(dr["UserId"]);
                    _Rec.PageId = Convert.ToInt32(dr["PageId"]);
                    _Rec.PageColumnId = Convert.ToInt32(dr["PageColumnId"]);
                    _Rec.ReplyFirstName = AES_Algorithm.DecryptString(dr["FirstName"].ToString());
                    _Rec.ReplyLastName = AES_Algorithm.DecryptString(dr["LastName"].ToString());
                    _Rec.ReplyPhoto = dr["Photo"].ToString();
                    if (_Rec.ReplyPhoto != null || _Rec.ReplyPhoto != "")
                        _Rec.ReplyPhoto = dr["Photo"].ToString();
                    else
                        _Rec.ReplyPhoto = "";
                    _Rec.CommentedDate = Convert.ToDateTime(dr["CommentedDate"]);
                    _Rec.HavingParentCommentId = Convert.ToBoolean(dr["HavingParentCommentId"]);
                    if (_Rec.HavingParentCommentId)
                    {
                        _Rec.InnerComments = InnerResultSetData(_Result, _Rec.CommentId);
                    }
                    else
                        _Rec.InnerComments = new List<SE_Comments>();
                    _List.Add(_Rec);
                }
            }
            return _List;
        }
        private List<SE_Comments> InnerResultSetData(DataSet _Result, int CommentId)
        {
            List<SE_Comments> _InnerList = new List<SE_Comments>();
            foreach (DataRow dr in _Result.Tables[1].Rows)
            {
                SE_Comments _Rec = new SE_Comments();
                if (CommentId == Convert.ToInt32(dr["ParentCommentId"]))
                {
                    _Rec.CommentId = Convert.ToInt32(dr["CommentId"]);
                    _Rec.ParentCommentId = Convert.ToInt32(dr["ParentCommentId"]);
                    _Rec.Comments = dr["Comments"].ToString();
                    _Rec.ReplyUserId = Convert.ToInt32(dr["UserId"]);
                    _Rec.PageId = Convert.ToInt32(dr["PageId"]);
                    _Rec.PageColumnId = Convert.ToInt32(dr["PageColumnId"]);
                    _Rec.ReplyFirstName = AES_Algorithm.DecryptString(dr["FirstName"].ToString());
                    _Rec.ReplyLastName = AES_Algorithm.DecryptString(dr["LastName"].ToString());
                    _Rec.ReplyPhoto = dr["Photo"].ToString() != "" ? RSAPattern.Encrypt(dr["Photo"].ToString()) : "";
                    _Rec.CommentedDate = Convert.ToDateTime(dr["CommentedDate"]);
                    _Rec.HavingParentCommentId = Convert.ToBoolean(dr["HavingParentCommentId"]);
                    if (_Rec.HavingParentCommentId)
                        _Rec.InnerComments = InnerResultSetData(_Result, _Rec.CommentId);
                    else
                        _Rec.InnerComments = new List<SE_Comments>();
                    _InnerList.Add(_Rec);
                }
            }
            return _InnerList;
        }
        public List<SE_RefValues> CommunityList()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT UserId, FirstName, LastName FROM [EuroDB].[tbl_Users] WHERE IsActive = 1 AND RoleId = (SELECT RoleId FROM eurodb.Ref_Roles WHERE [Code] = @RoleCode)", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@RoleCode", GlobalVariables.Shared.CommunityRole);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                    {
                        string FullVal = AES_Algorithm.DecryptString(dr["FirstName"].ToString()) + " " + AES_Algorithm.DecryptString(dr["LastName"].ToString());
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["UserId"]), Description = FullVal });
                    }

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}