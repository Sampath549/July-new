﻿using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Application.Models.DataObjects
{
    public partial class CPanelDevDAL : DataAccessComponent
    {
        public List<SE_RefValues> GetRolesGrid()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT * FROM [EuroDB].[Ref_Roles]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["RoleId"]), Code = dr["Code"].ToString(), Description = dr["Description"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int SaveUpdateRole(string Code, string Desc, string btnType)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_Roles";
                cmd.Parameters.Add("@Code", SqlDbType.VarChar).Value = Code;
                cmd.Parameters.Add("@Desc", SqlDbType.VarChar).Value = Desc;
                cmd.Parameters.Add("@btnType", SqlDbType.VarChar).Value = btnType;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int DeleteRole(string Code)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_Roles";
                cmd.Parameters.Add("@Code", SqlDbType.VarChar).Value = Code;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_Menus> GetMenusGrid()
        {
            try
            {
                List<SE_Menus> _Rec = new List<SE_Menus>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT * FROM [EuroDB].[tbl_Menus]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Menus { ParentId = Convert.ToInt32(dr["ParentId"]), Header = dr["Header"].ToString(), Controller = dr["Controller"].ToString(), Action = dr["Action"].ToString(), HavingChild = Convert.ToBoolean(dr["HavingChild"]), Order = Convert.ToInt32(dr["Order"]), Icon = dr["Icon"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int InsertUpdateMenus(SE_Menus _Menus, string Type)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_Menus";
                cmd.Parameters.Add("@Type", SqlDbType.VarChar).Value = Type;
                cmd.Parameters.Add("@ParentId", SqlDbType.VarChar).Value = _Menus.ParentId;
                cmd.Parameters.Add("@Header", SqlDbType.VarChar).Value = _Menus.Header;
                cmd.Parameters.Add("@Controller", SqlDbType.VarChar).Value = _Menus.Controller;
                cmd.Parameters.Add("@Action", SqlDbType.VarChar).Value = _Menus.Action;
                cmd.Parameters.Add("@HavingChild", SqlDbType.Bit).Value = _Menus.HavingChild;
                cmd.Parameters.Add("@Order", SqlDbType.Int).Value = _Menus.Order;
                cmd.Parameters.Add("@Icon", SqlDbType.VarChar).Value = _Menus.Icon;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public SE_Menus EditMenus(int ParentId)
        {
            try
            {
                SE_Menus _Menus = new SE_Menus();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT * FROM [EuroDB].[tbl_Menus] WHERE ParentId = @ParentId", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@ParentId", ParentId);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                {
                    _Menus.ParentId = ParentId;
                    _Menus.Header = _Result.Tables[0].Rows[0]["Header"].ToString();
                    _Menus.Controller = _Result.Tables[0].Rows[0]["Controller"].ToString();
                    _Menus.Action = _Result.Tables[0].Rows[0]["Action"].ToString();
                    _Menus.HavingChild = Convert.ToBoolean(_Result.Tables[0].Rows[0]["HavingChild"]);
                    _Menus.Order = Convert.ToInt32(_Result.Tables[0].Rows[0]["Order"]);
                    _Menus.Icon = _Result.Tables[0].Rows[0]["Icon"].ToString();
                }
                return _Menus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int DeleteMenus(int ParentId)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_Menus";
                cmd.Parameters.Add("@ParentId", SqlDbType.VarChar).Value = ParentId;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_SubMenus> GetSubMenusGrid()
        {
            try
            {
                List<SE_SubMenus> _Rec = new List<SE_SubMenus>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"  SELECT 
                                                SM.ChildId,
                                                SM.ParentId,
	                                            M.Header [ParentHeader],
	                                            SM.Header,
	                                            SM.Controller,
	                                            SM.[Action],
	                                            SM.[Order]
                                            FROM [EuroDB].[tbl_SubMenus] SM
                                            INNER JOIN [EuroDB].[tbl_Menus] M ON SM.ParentId = M.ParentId";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_SubMenus { ChildId = Convert.ToInt32(dr["ChildId"]), ParentId = Convert.ToInt32(dr["ParentId"]), ParentHeader = Convert.ToString(dr["ParentHeader"]), Header = dr["Header"].ToString(), Controller = dr["Controller"].ToString(), Action = dr["Action"].ToString(), Order = Convert.ToInt32(dr["Order"]) });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int InsertUpdateSubMenus(SE_SubMenus _SubMenus, string Type)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_SubMenus";
                cmd.Parameters.Add("@Type", SqlDbType.VarChar).Value = Type;
                cmd.Parameters.Add("@ChildId", SqlDbType.VarChar).Value = _SubMenus.ChildId;
                cmd.Parameters.Add("@ParentId", SqlDbType.VarChar).Value = _SubMenus.ParentId;
                cmd.Parameters.Add("@Header", SqlDbType.VarChar).Value = _SubMenus.Header;
                cmd.Parameters.Add("@Controller", SqlDbType.VarChar).Value = _SubMenus.Controller;
                cmd.Parameters.Add("@Action", SqlDbType.VarChar).Value = _SubMenus.Action;
                cmd.Parameters.Add("@Order", SqlDbType.Int).Value = _SubMenus.Order;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public SE_SubMenus EditSubMenus(int ChildId)
        {
            try
            {
                SE_SubMenus _SubMenus = new SE_SubMenus();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"  SELECT 
                                                SM.ChildId,
                                                SM.ParentId,
	                                            M.Header [ParentHeader],
	                                            SM.Header,
	                                            SM.Controller,
	                                            SM.[Action],
	                                            SM.[Order]
                                            FROM [EuroDB].[tbl_SubMenus] SM
                                            INNER JOIN [EuroDB].[tbl_Menus] M ON SM.ParentId = M.ParentId
                                            WHERE SM.ChildId = @ChildId
                                        ";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@ChildId", ChildId);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                {
                    _SubMenus.ChildId = ChildId;
                    _SubMenus.ParentId = Convert.ToInt32(_Result.Tables[0].Rows[0]["ParentId"]);
                    _SubMenus.ParentHeader = Convert.ToString(_Result.Tables[0].Rows[0]["ParentHeader"]);
                    _SubMenus.Header = _Result.Tables[0].Rows[0]["Header"].ToString();
                    _SubMenus.Controller = _Result.Tables[0].Rows[0]["Controller"].ToString();
                    _SubMenus.Action = _Result.Tables[0].Rows[0]["Action"].ToString();
                    _SubMenus.Order = Convert.ToInt32(_Result.Tables[0].Rows[0]["Order"]);
                }
                return _SubMenus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int DeleteSubMenus(int ChildId)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_SubMenus";
                cmd.Parameters.Add("@ChildId", SqlDbType.VarChar).Value = ChildId;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_AssignedMenus> GetAssignedMenusGrid()
        {
            try
            {
                List<SE_AssignedMenus> _Rec = new List<SE_AssignedMenus>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"  SELECT 
	                                            AM.AssignMenuId,
	                                            AM.ParentId,
	                                            M.Header [ParentHeader],
	                                            AM.RoleId,
	                                            R.Description [RoleDesc]
                                            FROM [EuroDB].[tbl_AssignMenus] AM
                                            INNER JOIN [EuroDB].[tbl_Menus] M ON AM.ParentId = M.ParentId
                                            INNER JOIN [EuroDB].[Ref_Roles] R ON AM.RoleId= R.RoleId";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_AssignedMenus { AssignedMenuId = Convert.ToInt32(dr["AssignMenuId"]), ParentId = Convert.ToInt32(dr["ParentId"]), ParentHeader = Convert.ToString(dr["ParentHeader"]), RoleId = Convert.ToInt32(dr["RoleId"]), RoleDesc = dr["RoleDesc"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int InsertUpdateAssignedMenus(SE_AssignedMenus _AMenus, string Type)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_AssignedMenus";
                cmd.Parameters.Add("@Type", SqlDbType.VarChar).Value = Type;
                cmd.Parameters.Add("@AssignedMenuId", SqlDbType.VarChar).Value = _AMenus.AssignedMenuId;
                cmd.Parameters.Add("@ParentId", SqlDbType.VarChar).Value = _AMenus.ParentId;
                cmd.Parameters.Add("@RoleId", SqlDbType.VarChar).Value = _AMenus.RoleId;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public SE_AssignedMenus EditAssignedMenus(int AssignMenuId)
        {
            try
            {
                SE_AssignedMenus _AMenus = new SE_AssignedMenus();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"  SELECT 
	                                            AM.AssignMenuId,
	                                            AM.ParentId,
	                                            M.Header [ParentHeader],
	                                            AM.RoleId,
	                                            R.Description [RoleDesc]
                                            FROM [EuroDB].[tbl_AssignMenus] AM
                                            INNER JOIN [EuroDB].[tbl_Menus] M ON AM.ParentId = M.ParentId
                                            INNER JOIN [EuroDB].[Ref_Roles] R ON AM.RoleId= R.RoleId
                                            WHERE AM.AssignMenuId = @AssignMenuId
                                        ";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@AssignMenuId", AssignMenuId);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                {
                    _AMenus.AssignedMenuId = AssignMenuId;
                    _AMenus.ParentId = Convert.ToInt32(_Result.Tables[0].Rows[0]["ParentId"]);
                    _AMenus.ParentHeader = Convert.ToString(_Result.Tables[0].Rows[0]["ParentHeader"]);
                    _AMenus.RoleId = Convert.ToInt32(_Result.Tables[0].Rows[0]["RoleId"]);
                    _AMenus.RoleDesc = Convert.ToString(_Result.Tables[0].Rows[0]["RoleDesc"]);
                }
                return _AMenus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int DeleteAssignedMenus(int AssignMenuId)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_AssignedMenus";
                cmd.Parameters.Add("@AssignMenuId", SqlDbType.VarChar).Value = AssignMenuId;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_RefValues> GetCountriesGrid()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT * FROM [EuroDB].[Ref_Countries]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["CountryId"]), Code = dr["Code"].ToString(), Description = dr["Description"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int InsertUpdateCountries(string Id, string Code, string Desc, string Type)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_Countries";
                cmd.Parameters.Add("@Type", SqlDbType.VarChar).Value = Type;
                cmd.Parameters.Add("@Id", SqlDbType.VarChar).Value = Id;
                cmd.Parameters.Add("@Code", SqlDbType.VarChar).Value = Code;
                cmd.Parameters.Add("@Desc", SqlDbType.VarChar).Value = Desc;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public SE_RefValues EditCountries(int CountryId)
        {
            try
            {
                SE_RefValues _Val = new SE_RefValues();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT * FROM [EuroDB].[Ref_Countries] WHERE CountryId= @CountryId", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@CountryId", CountryId);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                {
                    _Val.Id = CountryId;
                    _Val.Code = _Result.Tables[0].Rows[0]["Code"].ToString();
                    _Val.Description = _Result.Tables[0].Rows[0]["Description"].ToString();
                }
                return _Val;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int DeleteCountries(int CountryId)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_Countries";
                cmd.Parameters.Add("@Id", SqlDbType.VarChar).Value = CountryId;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_States> GetStatesGrid()
        {
            try
            {
                List<SE_States> _Rec = new List<SE_States>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"  SELECT 
	                                            S.StateId,
	                                            C.[CountryId],
	                                            C.[Description] [CountryName],
	                                            S.Code,
	                                            S.[Description]
                                            FROM [EuroDB].[Ref_States] S
                                            INNER JOIN [EuroDB].[Ref_Countries] C ON C.CountryId = S.CountryId";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_States { Id = Convert.ToInt32(dr["StateId"]), CountryId = Convert.ToInt32(dr["CountryId"]), CountryName = dr["CountryName"].ToString(), Code = dr["Code"].ToString(), Description = dr["Description"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int InsertUpdateStates(string Id, string CountryId, string Code, string Desc, string Type)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_States";
                cmd.Parameters.Add("@Type", SqlDbType.VarChar).Value = Type;
                cmd.Parameters.Add("@CountryId", SqlDbType.VarChar).Value = CountryId;
                cmd.Parameters.Add("@Id", SqlDbType.VarChar).Value = Id;
                cmd.Parameters.Add("@Code", SqlDbType.VarChar).Value = Code;
                cmd.Parameters.Add("@Desc", SqlDbType.VarChar).Value = Desc;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public SE_States EditStates(int StateId)
        {
            try
            {
                SE_States _Val = new SE_States();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"  SELECT 
	                                            S.StateId,
	                                            C.[CountryId],
	                                            C.[Description] [CountryName],
	                                            S.Code,
	                                            S.[Description]
                                            FROM [EuroDB].[Ref_States] S
                                            INNER JOIN [EuroDB].[Ref_Countries] C ON C.CountryId = S.CountryId
                                            WHERE StateId= @StateId";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@StateId", StateId);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                {
                    _Val.Id = StateId;
                    _Val.CountryId = Convert.ToInt32(_Result.Tables[0].Rows[0]["CountryId"]);
                    _Val.Code = _Result.Tables[0].Rows[0]["Code"].ToString();
                    _Val.Description = _Result.Tables[0].Rows[0]["Description"].ToString();
                }
                return _Val;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int DeleteStates(int StateId)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_States";
                cmd.Parameters.Add("@Id", SqlDbType.VarChar).Value = StateId;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
    }
}