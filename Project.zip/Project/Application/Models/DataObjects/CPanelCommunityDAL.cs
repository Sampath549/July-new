﻿using Application.Helper;
using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Application.Models.DataObjects
{
    public partial class CPanelCommunityDAL : DataAccessComponent
    {
        public List<SE_BMembers> GridBMembers(int CID)
        {
            try
            {
                List<SE_BMembers> _Rec = new List<SE_BMembers>();
                List<SE_MyProfile> _Users = new List<SE_MyProfile>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_GridBMembers", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@CID", CID);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                    {
                        SE_MyProfile MyDetails = new SE_MyProfile();
                        if (!string.IsNullOrEmpty(dr["UserId"].ToString()))
                            MyDetails.UserId = Convert.ToInt32(dr["UserId"]);

                        if (!string.IsNullOrEmpty(dr["FirstName"].ToString()))
                            MyDetails.FirstName = AES_Algorithm.DecryptString(dr["FirstName"].ToString());

                        if (!string.IsNullOrEmpty(dr["LastName"].ToString()))
                            MyDetails.LastName = AES_Algorithm.DecryptString(dr["LastName"].ToString());

                        if (!string.IsNullOrEmpty(dr["Photo"].ToString()))
                            MyDetails.ProfilePic = dr["Photo"].ToString();

                        if (!string.IsNullOrEmpty(dr["IsPermanentAddress"].ToString()))
                            MyDetails.isCurrentPermanent = Convert.ToBoolean(dr["IsPermanentAddress"]);

                        if (!string.IsNullOrEmpty(dr["PAddress"].ToString()))
                            MyDetails.PAddress = dr["PAddress"].ToString();

                        if (!string.IsNullOrEmpty(dr["PCity"].ToString()))
                            MyDetails.PCity = dr["PCity"].ToString();

                        if (!string.IsNullOrEmpty(dr["PStateDesc"].ToString()))
                            MyDetails.PStateDesc = dr["PStateDesc"].ToString();

                        if (!string.IsNullOrEmpty(dr["PCountryDesc"].ToString()))
                            MyDetails.PCountryDesc = dr["PCountryDesc"].ToString();

                        if (!string.IsNullOrEmpty(dr["PZipCode"].ToString()))
                            MyDetails.PZipCode = dr["PZipCode"].ToString();

                        if (!string.IsNullOrEmpty(dr["CAddress"].ToString()))
                            MyDetails.CAddress = dr["CAddress"].ToString();

                        if (!string.IsNullOrEmpty(dr["CCity"].ToString()))
                            MyDetails.CCity = dr["CCity"].ToString();

                        if (!string.IsNullOrEmpty(dr["CStateDesc"].ToString()))
                            MyDetails.CStateDesc = dr["CStateDesc"].ToString();

                        if (!string.IsNullOrEmpty(dr["CCountryDesc"].ToString()))
                            MyDetails.CCountryDesc = dr["CCountryDesc"].ToString();

                        if (!string.IsNullOrEmpty(dr["CZipCode"].ToString()))
                            MyDetails.CZipCode = dr["CZipCode"].ToString();

                        _Users.Add(MyDetails);
                    }
                }

                SE_BMembers BM = new SE_BMembers();
                BM.UserDetails = _Users;
                _Rec.Add(BM);

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int InsertBMembers(SE_BMembers _Rec)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                DataTable _dt = new DataTable();
                _dt.Columns.Add("Id");
                _dt.Columns.Add("UserId");
                int i = 1;
                if (_Rec.UserIds != null)
                {
                    foreach (var Rec in _Rec.UserIds)
                    {
                        DataRow _dr = _dt.NewRow();
                        _dr["Id"] = i;
                        _dr["UserId"] = Rec;
                        _dt.Rows.Add(_dr);
                        i++;
                    }
                }

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_BMembers";
                cmd.Parameters.Add("@CUserId", SqlDbType.VarChar).Value = _Rec.CUserId;
                cmd.Parameters.Add("@tbl_UserIds", SqlDbType.Structured).Value = _dt;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_Events> GetEvents(int? UID)
        {
            try
            {
                List<SE_Events> _Rec = new List<SE_Events>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_GridEvents", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@UID", UID);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Events
                        {
                            EventId = Convert.ToInt32(dr["EventId"]),
                            UserId = Convert.ToInt32(dr["UserId"]),
                            Title = dr["Title"].ToString(),
                            CreatedDate = Convert.ToDateTime(dr["CreatedDate"]),
                            DateLongString = dr["DateLongString"].ToString()
                        });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public SE_Events SingleEvent(int UID, int EventId)
        {
            try
            {
                List<SE_Events> _PageList = new List<SE_Events>();
                DataSet _PageResult = new DataSet();
                DataSet _ImagesResult = new DataSet();

                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("[USP_Get_EventById]", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@UID", UID);
                        da.SelectCommand.Parameters.AddWithValue("@EventId", EventId);
                        da.Fill(_PageResult);
                    }
                    con.Close();
                }

                DataTable DT = CopyDataTable(_PageResult.Tables[1], _PageResult.Tables[1].Rows.Count);
                _ImagesResult.Tables.Add(DT);

                if (_PageResult.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _PageResult.Tables[0].Rows)
                    {
                        _PageList.Add(new SE_Events
                        {
                            EventId = Convert.ToInt32(dr["EventId"]),
                            UserId = Convert.ToInt32(dr["UserId"]),
                            FirstName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(dr["FirstName"].ToString())),
                            LastName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(dr["LastName"].ToString())),
                            FullName = AES_Algorithm.DecryptString(dr["FirstName"].ToString()) + " " + AES_Algorithm.DecryptString(dr["LastName"].ToString()),
                            Title = dr["Title"].ToString(),
                            Description = dr["Description"].ToString(),
                            CreatedDate = Convert.ToDateTime(dr["CreatedDate"]),
                            DateLongString = dr["DateLongString"].ToString(),
                            Images = GetInnerEventsImages(_ImagesResult)
                        });
                    }

                return _PageList[0];
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable CopyDataTable(DataTable dtSource, int iRowsNeeded)
        {
            DataTable dtDestination = dtSource.Clone();
            for (int i = 0; i < iRowsNeeded; i++)
                dtDestination.ImportRow(dtSource.Rows[i]);
            return dtDestination;
        }

        private List<SE_EventImages> GetInnerEventsImages(DataSet ds)
        {
            List<SE_EventImages> _lst = new List<SE_EventImages>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                SE_EventImages _Rec = new SE_EventImages();
                _Rec.ImagePath = System.Uri.EscapeUriString(dr["ImagePath"].ToString());
                _Rec.ImgType = dr["ImgType"].ToString();
                _lst.Add(_Rec);
            }
            return _lst;
        }

        public int InsertEvents(SE_Events _Rec)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                DataTable _dt = new DataTable();
                _dt.Columns.Add("ImgId");
                _dt.Columns.Add("ImagePath");
                _dt.Columns.Add("ImgType");
                int i = 1;

                foreach (var Rec in _Rec.Images)
                {
                    DataRow _dr = _dt.NewRow();
                    _dr["ImgId"] = i;
                    _dr["ImagePath"] = Rec.ImagePath;
                    _dr["ImgType"] = Rec.ImgType;
                    _dt.Rows.Add(_dr);
                    i++;
                }

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_Events";
                cmd.Parameters.Add("@UserId", SqlDbType.VarChar).Value = _Rec.UserId;
                cmd.Parameters.Add("@Title", SqlDbType.VarChar).Value = _Rec.Title;
                cmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = _Rec.Description;
                cmd.Parameters.Add("@tbl_Gallery", SqlDbType.Structured).Value = _dt;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public List<SE_Polls> GetPolls(int? UID)
        {
            try
            {
                List<SE_Polls> _Rec = new List<SE_Polls>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_GridPolls", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@UID", UID);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Polls
                        {
                            PollId = Convert.ToInt32(dr["PollId"]),
                            Title = dr["Title"].ToString(),
                            Question = dr["Question"].ToString(),
                            YesPercentage = dr["YesPercent"].ToString(),
                            NoPercentage = dr["NoPercent"].ToString(),
                            DateLongString = dr["DateLongString"].ToString()
                        });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int InsertPolls(SE_Polls _Rec)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_Polls";
                cmd.Parameters.Add("@UserId", SqlDbType.VarChar).Value = _Rec.UserId;
                cmd.Parameters.Add("@Title", SqlDbType.VarChar).Value = _Rec.Title;
                cmd.Parameters.Add("@Question", SqlDbType.VarChar).Value = _Rec.Question;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
    }
}