﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_Polls
    {
        public int PollId { get; set; }
        public int UserId { get; set; }
        public string FullName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public string Question { get; set; }
        public string YesPercentage { get; set; }
        public string NoPercentage { get; set; }
        public DateTime CreatedDate { get; set; }
        public string DateLongString { get; set; }        
    }
}