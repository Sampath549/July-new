﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_Community
    {
    }

    public class SE_JoinCommunity
    {
        public int CommunityId { get; set; }
        public int UserId { get; set; }
    }

    public class SE_BMembers
    {
        public int CommunityId { get; set; }
        public int CUserId { get; set; }
        public int UserId { get; set; }
        public List<int> UserIds { get; set; }
        public List<SE_MyProfile> UserDetails { get; set; }
    }

    public class List_SE_BMembers
    {
        public IEnumerable<SE_BMembers> ListBMembers { get; set; }
    }
}