﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_Events
    {
        public int EventId { get; set; }
        public int UserId { get; set; }
        public string FullName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailCheck { get; set; }
        public string MobileCheck { get; set; }
        public string Title { get; set; }
        public string Gender { get; set; }
        public string Mobile { get; set; }
        public string City { get; set; }
        public string StateId { get; set; }
        public string StateCode { get; set; }
        public string StateDesc { get; set; }
        public string CountryId { get; set; }
        public string CountryCode { get; set; }
        public string CountryDesc { get; set; }
        public string ZipCode { get; set; }
        public string Description { get; set; }
        public DateTime CreatedDate { get; set; }
        public string DateLongString { get; set; }
        public int TotalComments { get; set; }
        public int TotalRecords { get; set; }
        public HttpPostedFile Uploads { get; set; }
        public string ImagePath { get; set; }
        public string ImgType { get; set; }
        public string ConfigUrl { get; set; }
        public List<SE_EventImages> Images { get; set; }
    }

    public class List_SE_Events
    {
        public IEnumerable<SE_Events> ListEvents { get; set; }
    }

    public class SE_EventImages
    {
        public string ImagePath { get; set; }
        public string ImgType { get; set; }
    }
}