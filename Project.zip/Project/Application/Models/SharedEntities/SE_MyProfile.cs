﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_MyProfile
    {
        public int? UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string RoleCode { get; set; }
        public int? RoleId { get; set; }
        public string Gender { get; set; }
        public string PAddress { get; set; }
        public string PCity { get; set; }
        public string PStateId { get; set; }
        public string PStateCode { get; set; }
        public string PStateDesc { get; set; }
        public string PCountryId { get; set; }
        public string PCountryCode { get; set; }
        public string PCountryDesc { get; set; }
        public string PZipCode { get; set; }
        public bool isCurrentPermanent { get; set; }
        public string CAddress { get; set; }
        public string CCity { get; set; }
        public string CStateId { get; set; }
        public string CStateCode { get; set; }
        public string CStateDesc { get; set; }
        public string CCountryId { get; set; }
        public string CCountryCode { get; set; }
        public string CCountryDesc { get; set; }
        public string CZipCode { get; set; }
        public string ProfilePic { get; set; }
        public string ImgType { get; set; }
        public string FileSize { get; set; }
    }
}