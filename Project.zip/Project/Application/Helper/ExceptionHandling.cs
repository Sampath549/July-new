﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Application.Helper
{
    public class ExceptionHandling
    {
        public static string ErrorPage(Exception ex, int Code)
        {
            if (GlobalVariables.Shared.InsertErrorLog)
                SendErrorToText(ex);

            var StatusCode = Code;
            string _PageRedirect = string.Empty;

            switch (StatusCode)
            {
                case 500:
                    _PageRedirect = GlobalVariables.Shared.InternalServerError;
                    break;
                default:
                    _PageRedirect = GlobalVariables.Shared.InternalServerError;
                    break;
            }
            return _PageRedirect;
        }

        private static String ErrorlineNo, Errormsg, extype, exurl, ErrorLocation;
        public static bool SendErrorToText(Exception ex)
        {
            var _BreakLine = Environment.NewLine;
            string[] GetLine = ex.StackTrace.Split(new string[] { ":line " }, StringSplitOptions.None);
            if (GetLine.Length > 1)
                ErrorlineNo = GetLine[1];
            Errormsg = ex.GetType().Name.ToString();
            extype = ex.GetType().ToString();
            exurl = System.Web.HttpContext.Current.Request.Url.ToString();
            ErrorLocation = ex.Message.ToString();

            try
            {
                string filepath = System.Web.HttpContext.Current.Server.MapPath("~/AccessFolders/ErrorLog/");  //Text File Path
                if (!Directory.Exists(filepath))
                    Directory.CreateDirectory(filepath);

                filepath = filepath + DateTime.Today.ToString("dd-MM-yy") + ".txt";   //Text File Name
                if (!File.Exists(filepath))
                    File.Create(filepath).Dispose();

                using (StreamWriter sw = File.AppendText(filepath))
                {
                    string _ErrorDetails = "Error Date & Time:" + " " + DateTime.Now.ToString() + _BreakLine;
                    _ErrorDetails = _ErrorDetails + "Error Line No:" + " " + ErrorlineNo + _BreakLine;
                    _ErrorDetails = _ErrorDetails + "Error Message:" + " " + Errormsg + _BreakLine;
                    _ErrorDetails = _ErrorDetails + "Exception Type:" + " " + extype + _BreakLine;
                    _ErrorDetails = _ErrorDetails + "Error Location:" + " " + ErrorLocation + _BreakLine;
                    _ErrorDetails = _ErrorDetails + "Error Page Url:" + " " + exurl;

                    sw.WriteLine("-----------------------------------------------------------------");
                    sw.WriteLine(_ErrorDetails);
                    sw.WriteLine("------------------------------/End/------------------------------");
                    sw.WriteLine(_BreakLine);
                    sw.Flush();
                    sw.Close();
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}