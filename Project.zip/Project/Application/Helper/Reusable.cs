﻿using Application.Models.SharedEntities;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.Helper
{
    public static class Reusable
    {
        public static string BindMenus()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                if (SessionHandler.Menus == null || SessionHandler.Menus == "")
                {
                    //API Call		
                    ArrayList _Array = new ArrayList();
                    _Array.Add(RSAPattern.Encrypt(_SessionUserDetails.RoleCode));
                    string _Menu = ApiHelper.PostData_Json("api/CPanel/BindMenus?Values=", _Array);
                    Result<string> _Result = JsonConvert.DeserializeObject<Result<string>>(_Menu);

                    SessionHandler.Menus = _Result.Data;
                }
                return SessionHandler.Menus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static string RedirectPage(string RoleCode)
        {
            try
            {
                if (RoleCode == GlobalVariables.Shared.DeveloperRole)
                    return GlobalVariables.Shared.DeveloperRedirectPage;
                else if (RoleCode == GlobalVariables.Shared.UserRole)
                    return GlobalVariables.Shared.UserRedirectPage;
                else if (RoleCode == GlobalVariables.Shared.BusinessRole)
                    return GlobalVariables.Shared.BusinessRedirectPage;
                else if (RoleCode == GlobalVariables.Shared.CommunityRole)
                    return GlobalVariables.Shared.CommunityRedirectPage;
                else if (RoleCode == GlobalVariables.Shared.SAdminRole)
                    return GlobalVariables.Shared.SAdminRedirectPage;
                else if (RoleCode == GlobalVariables.Shared.AdminRole)
                    return GlobalVariables.Shared.AdminRedirectPage;
                else
                    return "";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static bool CheckIsFirstTimeLogin()
        {
            try
            {
                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
                if (_SessionUserDetails.IsFirstTimeLogin)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static bool BrowserCheck(string BrowserName)
        {
            try
            {
                List<string> _ext = AllowedBrowsers();
                if (_ext.Contains(BrowserName))
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private static List<string> AllowedBrowsers()
        {
            try
            {
                List<string> _ext = new List<string>();
                string[] _Values = GlobalVariables.Shared.AllowedBrowsers.Split(new string[] { "," }, StringSplitOptions.None);

                foreach (string val in _Values)
                    _ext.Add(val.Trim());

                return _ext;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> RolesList()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                List<SelectListItem> _List = new List<SelectListItem>();
                if (SessionHandler.Roles == null)
                {
                    //API Call
                    ArrayList _Array = new ArrayList();
                    string _Roles = ApiHelper.PostData_Json("api/CPanel/RolesList?Values=", _Array);
                    Result<List<SE_RefValues>> _ResultRoles = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Roles);

                    _List.Add(new SelectListItem { Text = "Select Role", Value = "0" });
                    for (int k = 0; k < _ResultRoles.Data.Count; k++)
                    {
                        _List.Add(new SelectListItem
                        {
                            Text = _ResultRoles.Data[k].Description.ToString(),
                            Value = _ResultRoles.Data[k].Id.ToString()
                        });
                    }
                    SessionHandler.Roles = _List;
                }
                return SessionHandler.Roles;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> GenderList()
        {
            try
            {
                List<SelectListItem> GenderList = new List<SelectListItem>();
                GenderList.Add(new SelectListItem { Text = "Select Gender", Value = "0" });
                GenderList.Add(new SelectListItem { Text = "Male", Value = "1" });
                GenderList.Add(new SelectListItem { Text = "Female", Value = "2" });
                GenderList.Add(new SelectListItem { Text = "Other", Value = "3" });
                return GenderList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> CountriesList()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                List<SelectListItem> CountriesList = new List<SelectListItem>();
                if (SessionHandler.Countries == null)
                {
                    //API Call
                    ArrayList _Array = new ArrayList();
                    string _Countries = ApiHelper.PostData_Json("api/CPanel/GetCountries?Values=", _Array);
                    Result<List<SE_RefValues>> _ResultCountries = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Countries);

                    CountriesList.Add(new SelectListItem { Text = "Select Country", Value = "0" });
                    for (int k = 0; k < _ResultCountries.Data.Count; k++)
                    {
                        CountriesList.Add(new SelectListItem
                        {
                            Text = _ResultCountries.Data[k].Description.ToString(),
                            Value = _ResultCountries.Data[k].Id.ToString()
                        });
                    }
                    SessionHandler.Countries = CountriesList;
                }
                return SessionHandler.Countries;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> StatesList()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                List<SelectListItem> StatesList = new List<SelectListItem>();
                if (SessionHandler.States == null)
                {
                    ArrayList _Array = new ArrayList();
                    string _States = ApiHelper.PostData_Json("api/CPanel/GetStates?Values=", _Array);
                    Result<List<SE_RefValues>> _ResultStates = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_States);

                    StatesList.Add(new SelectListItem { Text = "Select State", Value = "0" });
                    for (int i = 0; i < _ResultStates.Data.Count; i++)
                    {
                        StatesList.Add(new SelectListItem
                        {
                            Text = _ResultStates.Data[i].Description.ToString(),
                            Value = _ResultStates.Data[i].Id.ToString()
                        });
                    }
                    SessionHandler.States = StatesList;
                }
                return SessionHandler.States;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> ClassifiedsList()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                List<SelectListItem> ClassifiedsList = new List<SelectListItem>();
                if (SessionHandler.Classifieds == null)
                {
                    ArrayList _Array = new ArrayList();
                    string _States = ApiHelper.PostData_Json("api/CPanel/GetClassifieds?Values=", _Array);
                    Result<List<SE_RefValues>> _Result = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_States);

                    ClassifiedsList.Add(new SelectListItem { Text = "Select Classified", Value = "0" });
                    for (int i = 0; i < _Result.Data.Count; i++)
                    {
                        ClassifiedsList.Add(new SelectListItem
                        {
                            Text = _Result.Data[i].Description.ToString(),
                            Value = _Result.Data[i].Id.ToString()
                        });
                    }
                    SessionHandler.Classifieds = ClassifiedsList;
                }
                return SessionHandler.Classifieds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> AllUsersList()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                List<SelectListItem> AllUsersList = new List<SelectListItem>();
                if (SessionHandler.AllUsers == null)
                {
                    ArrayList _Array = new ArrayList();
                    string _States = ApiHelper.PostData_Json("api/CPanel/GetAllUsers?Values=", _Array);
                    Result<List<SE_RefValues>> _JsonResult = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_States);

                    AllUsersList.Add(new SelectListItem { Text = "Select State", Value = "0" });
                    for (int i = 0; i < _JsonResult.Data.Count; i++)
                    {
                        AllUsersList.Add(new SelectListItem
                        {
                            Text = _JsonResult.Data[i].Description.ToString(),
                            Value = _JsonResult.Data[i].Id.ToString()
                        });
                    }
                    SessionHandler.AllUsers = AllUsersList;
                }
                return SessionHandler.AllUsers;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<string> ProfilePicExtentions()
        {
            try
            {
                List<string> _ext = new List<string>();
                _ext.Add(".JPG");
                _ext.Add(".JPEG");
                _ext.Add(".PNG");
                _ext.Add(".jpg");
                _ext.Add(".jpge");
                _ext.Add(".png");
                return _ext;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<string> EventsExtentions()
        {
            try
            {
                List<string> _ext = new List<string>();
                _ext.Add("image/JPG");
                _ext.Add("image/JPEG");
                _ext.Add("image/PNG");
                _ext.Add("image/jpg");
                _ext.Add("image/jpeg");
                _ext.Add("image/png");
                return _ext;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static void SaveTempPasswords(string _Email, string _Pwd, string _Salt)
        {
            var _BreakLine = Environment.NewLine;

            try
            {
                string filepath = System.Web.HttpContext.Current.Server.MapPath("~/AccessFolders/Temp/");  //Text File Path
                if (!Directory.Exists(filepath))
                    Directory.CreateDirectory(filepath);

                filepath = filepath + "TempPasswords.txt";   //Text File Name
                if (!File.Exists(filepath))
                    File.Create(filepath).Dispose();

                using (StreamWriter sw = File.AppendText(filepath))
                {
                    string _Details = "Date & Time:" + " " + DateTime.Now.ToString() + _BreakLine;
                    _Details = _Details + "Email:" + " " + _Email + _BreakLine;
                    _Details = _Details + "Password:" + " " + _Pwd + _BreakLine;
                    _Details = _Details + "Salt Key:" + " " + _Salt;

                    sw.WriteLine("-----------------------------------------------------------------");
                    sw.WriteLine(_Details);
                    sw.WriteLine("------------------------------/End/------------------------------");
                    sw.WriteLine(_BreakLine);
                    sw.Flush();
                    sw.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static void SaveResetPwdLink(string _Email, string _Name, string _Url)
        {
            var _BreakLine = Environment.NewLine;

            try
            {
                string filepath = System.Web.HttpContext.Current.Server.MapPath("~/AccessFolders/Temp/");  //Text File Path
                if (!Directory.Exists(filepath))
                    Directory.CreateDirectory(filepath);

                filepath = filepath + "TempResetPwdLinks.txt";   //Text File Name
                if (!File.Exists(filepath))
                    File.Create(filepath).Dispose();

                using (StreamWriter sw = File.AppendText(filepath))
                {
                    string _Details = "Date & Time:" + " " + DateTime.Now.ToString() + _BreakLine;
                    _Details = _Details + "Email:" + " " + _Email + _BreakLine;
                    _Details = _Details + "Password:" + " " + _Name + _BreakLine;
                    _Details = _Details + "URL:" + " " + _Url;

                    sw.WriteLine("-----------------------------------------------------------------");
                    sw.WriteLine(_Details);
                    sw.WriteLine("------------------------------/End/------------------------------");
                    sw.WriteLine(_BreakLine);
                    sw.Flush();
                    sw.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static void SaveRegistration(string _PKey, string _Email, string _FName, string _LName, string _Mobile)
        {
            var _BreakLine = Environment.NewLine;

            try
            {
                string filepath = System.Web.HttpContext.Current.Server.MapPath("~/AccessFolders/Temp/");  //Text File Path
                if (!Directory.Exists(filepath))
                    Directory.CreateDirectory(filepath);

                filepath = filepath + "TempRegistrations.txt";   //Text File Name
                if (!File.Exists(filepath))
                    File.Create(filepath).Dispose();

                using (StreamWriter sw = File.AppendText(filepath))
                {
                    string _Details = "Date & Time:" + " " + DateTime.Now.ToString() + _BreakLine;
                    _Details = _Details + "Actual Email:" + " " + SymmetricAlgorithm.Decrypt(_Email) + _BreakLine;
                    _Details = _Details + "PersonalKey:" + " " + _PKey + _BreakLine;
                    _Details = _Details + "Email:" + " " + _Email + _BreakLine;
                    _Details = _Details + "FName:" + " " + _FName + _BreakLine;
                    _Details = _Details + "LName:" + " " + _LName + _BreakLine;
                    _Details = _Details + "Mobile:" + " " + _Mobile + _BreakLine;

                    sw.WriteLine("-----------------------------------------------------------------");
                    sw.WriteLine(_Details);
                    sw.WriteLine("------------------------------/End/------------------------------");
                    sw.WriteLine(_BreakLine);
                    sw.Flush();
                    sw.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<SelectListItem> ComunityList()
        {
            try
            {
                List<SelectListItem> _lst = new List<SelectListItem>();
                if (SessionHandler.SessionComunityList == null)
                {
                    ArrayList _Array = new ArrayList();
                    string _Studentslst = ApiHelper.PostData_Json("api/UserPresentation/CommunityList?Values=", _Array);
                    Result<List<SE_RefValues>> _Result = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Studentslst);

                    for (int i = 0; i < _Result.Data.Count; i++)
                    {
                        _lst.Add(new SelectListItem
                        {
                            Text = _Result.Data[i].Description.ToString(),
                            Value = _Result.Data[i].Id.ToString()
                        });
                    }
                    SessionHandler.SessionComunityList = _lst;
                }
                return SessionHandler.SessionComunityList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> RoomTypes()
        {
            try
            {
                List<SelectListItem> _Type = new List<SelectListItem>();
                _Type.Add(new SelectListItem { Text = "Select Room Type", Value = "0" });
                _Type.Add(new SelectListItem { Text = "Sharing Basis", Value = "Sharing Basis" });
                _Type.Add(new SelectListItem { Text = "Complete Flat / House", Value = "Complete Flat / House" });
                return _Type;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static string RawHTMLComments(IEnumerable<SE_Comments> _Comments)
        {

            string str = @"";
            List<SE_Comments> _Result = new List<SE_Comments>();
            foreach (SE_Comments Val in _Comments)
            {
                str += @"<li class='comment'>
                            <div class='comment-body'>
                                <div class='comment-author'>";

                if (Val.ReplyPhoto == "")
                    str += @"<span style = 'border: 1px solid #ccc; border-radius: 50%; float:left; height: 60px; width: 60px; max-width: 100%; margin-bottom:30px;  margin-right:25px; position:relative; color: #337ab7;font-size:38px; font-weight:700; line-height: 52px;text-align:center !important; vertical-align:middle;'>" + Val.ReplyFirstName.Trim().Substring(0, 1) + "</span>";
                else
                    str += @"<img class='avatar' src=" + Val.ReplyPhoto + " alt='Image'>";

                str += @"<span class='fn'>" + Val.ReplyFirstName + ' ' + Val.ReplyLastName + "</span>";
                str += @"</div>";

                str += @"<div class='comment-meta commentmetadata'><a href = '#' >" + Val.FullStringDate + " </a></div>";

                str += @"<div class='comment-content'>
                            <p>" + Val.Comments + "</p></div>";

                str += @"<div class='reply'>
                            <a href = '#' class='btn-link hrefLinkClick' onclick='MyFunc(" + Val.CommentId + ")'><i class='fa fa-reply' aria-hidden='true'></i> Reply</a>";
                str += @"<div id= '" + Val.CommentId + "' class='form-horizontal'></div>";
                str += @"</div></div>";

                if (Val.HavingParentCommentId && Val.InnerComments.Count > 0)
                {
                    str += InnerRawHTMLComments(Val.InnerComments);
                }
                str += " </li>";
            }
            return str;
        }
        private static string InnerRawHTMLComments(IEnumerable<SE_Comments> _Comments)
        {
            string str = @"";
            if (_Comments.ToList().Count > 0)
            {
                str += @"<ul class='children'>";
                foreach (SE_Comments IC in _Comments)
                {
                    str += @"<li class='comment'>
                            <div class='comment-body'>
                                <div class='comment-author'>";

                    if (IC.ReplyPhoto == "")
                        str += @"<span style = 'border: 1px solid #ccc; border-radius: 50%; float:left; height: 60px; margin-bottom:30px;  margin-right:25px; position:relative; width: 60px; max-width: 100%; color: #337ab7;font-size:38px; font-weight:700; line-height: 52px;text-align:center !important; vertical-align:middle;'>" + IC.ReplyFirstName.Trim().Substring(0, 1) + "</span>";
                    else
                        str += @"<img class='avatar' src=" + IC.ReplyPhoto + " alt='Image'>";

                    str += @"<span class='fn'>" + IC.ReplyFirstName + ' ' + IC.ReplyLastName + "</span>";
                    str += @"</div>";

                    str += @"<div class='comment-meta commentmetadata'><a href = '#' >" + IC.FullStringDate + " </a></div>";

                    str += @"<div class='comment-content'>
                            <p>" + IC.Comments + "</p></div>";

                    str += @"<div class='reply'>
                            <a href = '#' class='btn-link hrefLinkClick' onclick='MyFunc(" + IC.CommentId + ")'><i class='fa fa-reply' aria-hidden='true'></i> Reply</a>";
                    str += @"<div id= '" + IC.CommentId + "' class='form-horizontal'></div>";
                    str += @"</div></div>";
                    if (IC.HavingParentCommentId && IC.InnerComments.Count > 0)
                    {
                        string InnerStr = InnerRawHTMLComments(IC.InnerComments);
                        str += InnerStr;
                    }
                    str += @"</li>";
                }
                str += " </ul>";
            }
            return str;
        }
    }
}